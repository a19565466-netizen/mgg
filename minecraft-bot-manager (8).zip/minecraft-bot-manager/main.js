const { app, BrowserWindow, ipcMain, shell } = require('electron')
const path = require('path')
const fs = require('fs')
const https = require('https')
const os = require('os')
const { spawn, spawnSync } = require('child_process')

const botsDir = path.join(app.getPath('userData'), 'bots')
const storeFile = path.join(app.getPath('userData'), 'bots.json')
if (!fs.existsSync(botsDir)) fs.mkdirSync(botsDir, { recursive: true })

const processes = new Map() // id -> child process
let mainWindow

function loadStore() {
  if (!fs.existsSync(storeFile)) return []
  try { return JSON.parse(fs.readFileSync(storeFile, 'utf-8')) } catch { return [] }
}
function saveStore(list) {
  fs.writeFileSync(storeFile, JSON.stringify(list, null, 2))
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  })
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))
}

app.whenReady().then(createWindow)
app.on('window-all-closed', () => {
  // موقع بستن برنامه، همه بات‌های در حال اجرا هم متوقف می‌شن
  for (const proc of processes.values()) proc.kill()
  if (process.platform !== 'darwin') app.quit()
})

// ===== چک کردن و نصب خودکار Node.js اگه نصب نبود =====
function isNodeInstalled() {
  try {
    const result = spawnSync('node', ['--version'], { shell: true })
    return result.status === 0
  } catch {
    return false
  }
}

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'minecraft-bot-manager' } }, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try { resolve(JSON.parse(data)) } catch (e) { reject(e) }
      })
    }).on('error', reject)
  })
}

function downloadFile(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath, onProgress).then(resolve, reject)
      }
      const total = parseInt(res.headers['content-length'] || '0', 10)
      let downloaded = 0
      const fileStream = fs.createWriteStream(destPath)
      res.on('data', (chunk) => {
        downloaded += chunk.length
        if (total) onProgress(Math.round((downloaded / total) * 100))
      })
      res.pipe(fileStream)
      fileStream.on('finish', () => fileStream.close(resolve))
      fileStream.on('error', reject)
    }).on('error', reject)
  })
}

async function installNodeAutomatically(sendLog) {
  sendLog('در حال بررسی آخرین نسخه‌ی Node.js...')
  const index = await fetchJson('https://nodejs.org/dist/index.json')
  const lts = index.find((v) => v.lts)
  const version = lts.version // مثلاً v22.14.0
  const arch = os.arch() === 'x64' ? 'x64' : os.arch() === 'arm64' ? 'arm64' : 'x86'
  const fileName = `node-${version}-${arch}.msi`
  const url = `https://nodejs.org/dist/${version}/${fileName}`
  const destPath = path.join(os.tmpdir(), fileName)

  sendLog(`در حال دانلود Node.js ${version}...`)
  await downloadFile(url, destPath, (percent) => sendLog(`دانلود: ${percent}%`, true))

  sendLog('در حال نصب Node.js روی سیستم (ممکنه یه پنجره‌ی تایید ویندوز باز بشه)...')
  await new Promise((resolve, reject) => {
    const install = spawn('msiexec', ['/i', destPath, '/qb', '/norestart'], { shell: true })
    install.on('close', (code) => (code === 0 ? resolve() : reject(new Error('کد خروجی نصب: ' + code))))
    install.on('error', reject)
  })

  // مسیر پیش‌فرض نصب رو به PATH همین پروسه اضافه می‌کنیم تا نیاز به ری‌استارت برنامه نباشه
  const defaultInstallDir = 'C:\\Program Files\\nodejs'
  if (!process.env.PATH.includes(defaultInstallDir)) {
    process.env.PATH = defaultInstallDir + path.delimiter + process.env.PATH
  }

  sendLog('✅ Node.js با موفقیت نصب شد.')
}

ipcMain.handle('check-node', async () => {
  if (isNodeInstalled()) return { installed: true }

  const sendLog = (line) => mainWindow.webContents.send('node-install-log', { line })
  sendLog('Node.js روی سیستم پیدا نشد. شروع نصب خودکار...')
  try {
    await installNodeAutomatically(sendLog)
    const ok = isNodeInstalled()
    return { installed: ok }
  } catch (err) {
    sendLog('❌ خطا در نصب خودکار: ' + err.message)
    sendLog('لطفاً به‌صورت دستی از nodejs.org نصب کنید.')
    return { installed: false, error: err.message }
  }
})

function jsStringLiteral(value) {
  return JSON.stringify(String(value))
}

// ===== ساخت بات جدید =====
ipcMain.handle('create-bot', async (event, data) => {
  const id = 'bot_' + Date.now()
  const folder = path.join(botsDir, id)
  fs.mkdirSync(folder, { recursive: true })

  const template = fs.readFileSync(path.join(__dirname, 'bot-template.js'), 'utf-8')
  const botCode = template
    .replace('{{HOST}}', jsStringLiteral(data.host))
    .replace('{{PORT}}', Number(data.port) || 25565)
    .replace('{{USERNAME}}', jsStringLiteral(data.username))
    .replace('{{VERSION}}', jsStringLiteral(data.version))
    .replace('{{LOGIN_PASSWORD}}', jsStringLiteral(data.password || ''))

  fs.writeFileSync(path.join(folder, 'bot.js'), botCode)

  const pkgTemplate = fs.readFileSync(path.join(__dirname, 'bot-package-template.json'), 'utf-8')
  const pkg = pkgTemplate.replace('{{NAME}}', id)
  fs.writeFileSync(path.join(folder, 'package.json'), pkg)

  const list = loadStore()
  const entry = {
    id, name: data.name || id, host: data.host, port: data.port,
    username: data.username, version: data.version, password: data.password || '',
    apiKeyFa: data.apiKeyFa || '', apiKeyEn: data.apiKeyEn || '',
    folder, autoStart: !!data.autoStart
  }
  list.push(entry)
  saveStore(list)

  // نصب پکیج‌ها
  await new Promise((resolve) => {
    const install = spawn('npm', ['install'], { cwd: folder, shell: true })
    install.stdout.on('data', (d) => mainWindow.webContents.send('install-log', { id, line: d.toString() }))
    install.stderr.on('data', (d) => mainWindow.webContents.send('install-log', { id, line: d.toString() }))
    install.on('close', resolve)
  })

  mainWindow.webContents.send('install-log', { id, line: '✅ نصب کامل شد.' })
  return entry
})

// ===== لیست بات‌ها =====
ipcMain.handle('get-bots', () => {
  const list = loadStore()
  return list.map((b) => ({ ...b, running: processes.has(b.id) }))
})

// ===== استارت =====
ipcMain.handle('start-bot', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry || processes.has(id)) return { ok: false }

  const child = spawn('node', ['bot.js'], {
    cwd: entry.folder,
    env: {
      ...process.env,
      CLAUDE_API_KEY_FA: entry.apiKeyFa || '',
      CLAUDE_API_KEY_EN: entry.apiKeyEn || ''
    }
  })
  processes.set(id, child)

  child.stdout.on('data', (d) => mainWindow.webContents.send('bot-log', { id, line: d.toString() }))
  child.stderr.on('data', (d) => mainWindow.webContents.send('bot-log', { id, line: d.toString() }))
  child.on('close', () => {
    processes.delete(id)
    mainWindow.webContents.send('bot-status', { id, running: false })
  })

  mainWindow.webContents.send('bot-status', { id, running: true })
  return { ok: true }
})

// ===== استاپ =====
ipcMain.handle('stop-bot', (event, id) => {
  const proc = processes.get(id)
  if (proc) proc.kill()
  processes.delete(id)
  mainWindow.webContents.send('bot-status', { id, running: false })
  return { ok: true }
})

// ===== ارسال دستور به بات (مثل "چوب جمع کن") =====
ipcMain.handle('send-command', (event, { id, text }) => {
  const proc = processes.get(id)
  if (proc) proc.stdin.write(text + '\n')
  return { ok: true }
})

// ===== حذف بات =====
ipcMain.handle('delete-bot', (event, id) => {
  const proc = processes.get(id)
  if (proc) { proc.kill(); processes.delete(id) }

  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (entry && fs.existsSync(entry.folder)) {
    fs.rmSync(entry.folder, { recursive: true, force: true })
  }
  saveStore(list.filter((b) => b.id !== id))
  return { ok: true }
})

// ===== خوندن/ذخیره کد بات برای ویرایش داخل برنامه =====
ipcMain.handle('get-bot-code', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return ''
  return fs.readFileSync(path.join(entry.folder, 'bot.js'), 'utf-8')
})

ipcMain.handle('save-bot-code', (event, { id, code }) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }
  fs.writeFileSync(path.join(entry.folder, 'bot.js'), code)
  return { ok: true }
})

// ===== باز کردن پوشه بات (اختیاری) =====
ipcMain.handle('open-bot-folder', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (entry) shell.openPath(entry.folder)
  return { ok: true }
})

// ===== خوندن وضعیت زنده بات (جون، غذا، موقعیت، کار فعلی) =====
ipcMain.handle('get-bot-status', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return null
  const statusPath = path.join(entry.folder, 'status.json')
  if (!fs.existsSync(statusPath)) return null
  try {
    return JSON.parse(fs.readFileSync(statusPath, 'utf-8'))
  } catch {
    return null
  }
})

// ===== خوندن/ذخیره تنظیمات بات (آی‌پی، پورت، یوزرنیم، نسخه، رمز، کلیدهای API) =====
ipcMain.handle('get-bot-settings', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  return entry || null
})

ipcMain.handle('save-bot-settings', (event, { id, data }) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }

  entry.name = data.name || entry.name
  entry.host = data.host
  entry.port = data.port
  entry.username = data.username
  entry.version = data.version
  entry.password = data.password || ''
  entry.apiKeyFa = data.apiKeyFa || ''
  entry.apiKeyEn = data.apiKeyEn || ''
  saveStore(list)

  // بازسازی فایل bot.js با تنظیمات جدید (توجه: اگه دستی کد رو ویرایش کرده باشید، این بازنویسی می‌کنه)
  const template = fs.readFileSync(path.join(__dirname, 'bot-template.js'), 'utf-8')
  const botCode = template
    .replace('{{HOST}}', jsStringLiteral(entry.host))
    .replace('{{PORT}}', Number(entry.port) || 25565)
    .replace('{{USERNAME}}', jsStringLiteral(entry.username))
    .replace('{{VERSION}}', jsStringLiteral(entry.version))
    .replace('{{LOGIN_PASSWORD}}', jsStringLiteral(entry.password || ''))
  fs.writeFileSync(path.join(entry.folder, 'bot.js'), botCode)

  return { ok: true }
})

// ===== استارت خودکار بات‌هایی که autoStart دارن، موقع باز شدن برنامه =====
app.whenReady().then(() => {
  setTimeout(() => {
    const list = loadStore()
    for (const entry of list) {
      if (entry.autoStart) {
        const child = spawn('node', ['bot.js'], {
          cwd: entry.folder,
          env: {
            ...process.env,
            CLAUDE_API_KEY_FA: entry.apiKeyFa || '',
            CLAUDE_API_KEY_EN: entry.apiKeyEn || ''
          }
        })
        processes.set(entry.id, child)
        child.stdout.on('data', (d) => mainWindow.webContents.send('bot-log', { id: entry.id, line: d.toString() }))
        child.stderr.on('data', (d) => mainWindow.webContents.send('bot-log', { id: entry.id, line: d.toString() }))
        child.on('close', () => {
          processes.delete(entry.id)
          mainWindow.webContents.send('bot-status', { id: entry.id, running: false })
        })
      }
    }
  }, 1000)
})
