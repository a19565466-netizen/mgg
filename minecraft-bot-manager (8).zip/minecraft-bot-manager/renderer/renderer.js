let bots = []
let activeId = null

const botListEl = document.getElementById('botList')
const emptyState = document.getElementById('emptyState')
const botPanel = document.getElementById('botPanel')
const botTitle = document.getElementById('botTitle')
const consoleEl = document.getElementById('console')

async function refreshBots() {
  bots = await window.api.getBots()
  renderList()
}

function renderList() {
  botListEl.innerHTML = ''
  for (const b of bots) {
    const div = document.createElement('div')
    div.className = 'bot-item' + (b.id === activeId ? ' active' : '')
    div.innerHTML = `<span>${b.name}</span><span class="dot ${b.running ? 'on' : 'off'}"></span>`
    div.onclick = () => selectBot(b.id)
    botListEl.appendChild(div)
  }
}

function selectBot(id) {
  activeId = id
  const b = bots.find((x) => x.id === id)
  emptyState.classList.add('hidden')
  botPanel.classList.remove('hidden')
  botTitle.textContent = b.name + (b.running ? ' (روشن)' : ' (خاموش)')
  consoleEl.textContent = ''
  renderList()
}

// ===== نمایش زنده وضعیت بات (جون، غذا، موقعیت، کار فعلی) =====
setInterval(async () => {
  if (!activeId) return
  const status = await window.api.getBotStatus(activeId)
  if (!status) return
  document.getElementById('statHealth').textContent = `❤️ ${status.health ?? '--'}/20`
  document.getElementById('statFood').textContent = `🍗 ${status.food ?? '--'}/20`
  document.getElementById('statPos').textContent = status.position
    ? `📍 ${status.position.x}, ${status.position.y}, ${status.position.z}`
    : '📍 --'
  document.getElementById('statAction').textContent = `⚙️ ${status.currentAction || '--'}`
}, 2000)

// ===== دکمه‌های کنترل بات =====
document.getElementById('startBtn').onclick = async () => {
  if (!activeId) return
  await window.api.startBot(activeId)
  await refreshBots()
  selectBot(activeId)
}
document.getElementById('stopBtn').onclick = async () => {
  if (!activeId) return
  await window.api.stopBot(activeId)
  await refreshBots()
  selectBot(activeId)
}
document.getElementById('restartBtn').onclick = async () => {
  if (!activeId) return
  await window.api.stopBot(activeId)
  setTimeout(async () => {
    await window.api.startBot(activeId)
    await refreshBots()
    selectBot(activeId)
  }, 800)
}
document.getElementById('deleteBtn').onclick = async () => {
  if (!activeId) return
  if (!confirm('مطمئنی می‌خوای این بات رو کامل حذف کنی؟')) return
  await window.api.deleteBot(activeId)
  activeId = null
  botPanel.classList.add('hidden')
  emptyState.classList.remove('hidden')
  await refreshBots()
}

// ===== ارسال دستور =====
document.getElementById('sendCommandBtn').onclick = sendCommand
document.getElementById('commandInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendCommand()
})
function sendCommand() {
  const input = document.getElementById('commandInput')
  const text = input.value.trim()
  if (!text || !activeId) return
  window.api.sendCommand(activeId, text)
  input.value = ''
}

// ===== لاگ‌های زنده =====
window.api.onBotLog(({ id, line }) => {
  if (id !== activeId) return
  consoleEl.textContent += line
  consoleEl.scrollTop = consoleEl.scrollHeight
})
window.api.onBotStatus(async () => {
  await refreshBots()
  if (activeId) selectBot(activeId)
})

// ===== مودال ساخت بات جدید =====
const createModal = document.getElementById('createModal')
document.getElementById('newBotBtn').onclick = () => {
  ;['f_name','f_host','f_port','f_version','f_username','f_password','f_apikey_fa','f_apikey_en'].forEach((id) => document.getElementById(id).value = '')
  document.getElementById('f_autostart').checked = false
  document.getElementById('installLog').classList.add('hidden')
  document.getElementById('installLog').textContent = ''
  createModal.classList.remove('hidden')
}
document.getElementById('cancelCreate').onclick = () => createModal.classList.add('hidden')

document.getElementById('saveCreate').onclick = async () => {
  const data = {
    name: document.getElementById('f_name').value || 'بات جدید',
    host: document.getElementById('f_host').value,
    port: document.getElementById('f_port').value,
    version: document.getElementById('f_version').value,
    username: document.getElementById('f_username').value,
    password: document.getElementById('f_password').value,
    apiKeyFa: document.getElementById('f_apikey_fa').value,
    apiKeyEn: document.getElementById('f_apikey_en').value,
    autoStart: document.getElementById('f_autostart').checked
  }
  if (!data.host || !data.username) {
    alert('حداقل آی‌پی سرور و یوزرنیم رو وارد کن.')
    return
  }
  const logBox = document.getElementById('installLog')
  logBox.classList.remove('hidden')
  logBox.textContent = 'در حال ساخت پوشه و نصب پکیج‌ها... (ممکنه چند دقیقه طول بکشه)\n'

  const removeListener = window.api.onInstallLog(({ id, line }) => {
    logBox.textContent += line
    logBox.scrollTop = logBox.scrollHeight
  })

  await window.api.createBot(data)
  await refreshBots()
  setTimeout(() => createModal.classList.add('hidden'), 800)
}

// ===== مودال ویرایش کد =====
const editModal = document.getElementById('editModal')
document.getElementById('editBtn').onclick = async () => {
  if (!activeId) return
  const code = await window.api.getBotCode(activeId)
  document.getElementById('codeEditor').value = code
  editModal.classList.remove('hidden')
}
document.getElementById('cancelEdit').onclick = () => editModal.classList.add('hidden')
document.getElementById('saveEdit').onclick = async () => {
  const code = document.getElementById('codeEditor').value
  await window.api.saveBotCode(activeId, code)
  editModal.classList.add('hidden')
  alert('ذخیره شد. برای اعمال تغییرات، بات رو ری‌استارت کن.')
}

// ===== مودال ویرایش تنظیمات (آی‌پی، اسم، لاگین، کلیدهای API) =====
const settingsModal = document.getElementById('settingsModal')
document.getElementById('editSettingsBtn').onclick = async () => {
  if (!activeId) return
  const s = await window.api.getBotSettings(activeId)
  if (!s) return
  document.getElementById('s_name').value = s.name || ''
  document.getElementById('s_host').value = s.host || ''
  document.getElementById('s_port').value = s.port || ''
  document.getElementById('s_version').value = s.version || ''
  document.getElementById('s_username').value = s.username || ''
  document.getElementById('s_password').value = s.password || ''
  document.getElementById('s_apikey_fa').value = s.apiKeyFa || ''
  document.getElementById('s_apikey_en').value = s.apiKeyEn || ''
  settingsModal.classList.remove('hidden')
}
document.getElementById('cancelSettings').onclick = () => settingsModal.classList.add('hidden')
document.getElementById('saveSettings').onclick = async () => {
  const data = {
    name: document.getElementById('s_name').value,
    host: document.getElementById('s_host').value,
    port: document.getElementById('s_port').value,
    version: document.getElementById('s_version').value,
    username: document.getElementById('s_username').value,
    password: document.getElementById('s_password').value,
    apiKeyFa: document.getElementById('s_apikey_fa').value,
    apiKeyEn: document.getElementById('s_apikey_en').value
  }
  await window.api.saveBotSettings(activeId, data)
  await refreshBots()
  selectBot(activeId)
  settingsModal.classList.add('hidden')
  alert('تنظیمات ذخیره شد. برای اعمال تغییرات، بات رو ری‌استارت کن.')
}

refreshBots()

// ===== چک کردن و نصب خودکار Node.js موقع باز شدن برنامه =====
const nodeOverlay = document.getElementById('nodeOverlay')
const nodeInstallLog = document.getElementById('nodeInstallLog')
const newBotBtn = document.getElementById('newBotBtn')

window.api.onNodeInstallLog(({ line }) => {
  nodeOverlay.classList.remove('hidden')
  nodeInstallLog.textContent += line + '\n'
  nodeInstallLog.scrollTop = nodeInstallLog.scrollHeight
})

async function ensureNode() {
  newBotBtn.disabled = true
  const result = await window.api.checkNode()
  newBotBtn.disabled = false
  nodeOverlay.classList.add('hidden')
  if (!result.installed) {
    alert('نصب خودکار Node.js موفق نبود. لطفاً دستی از nodejs.org نصب کنید و برنامه رو دوباره باز کنید.')
  }
}
ensureNode()
