// bot.js — به‌صورت خودکار توسط برنامه ساخته شده

const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
const collectBlockPlugin = require('mineflayer-collectblock').plugin
const { plugin: autoEatPlugin } = require('mineflayer-auto-eat')
const readline = require('readline')
const fs = require('fs')
const path = require('path')

const BOT_DIR = __dirname
const MEMORY_FILE = path.join(BOT_DIR, 'memory.json')
const STATUS_FILE = path.join(BOT_DIR, 'status.json')

// ===== تنظیمات (توسط برنامه پر می‌شه) =====
// دو کلید API جدا: یکی برای مکالمات فارسی، یکی برای مکالمات انگلیسی
const CLAUDE_API_KEY_FA = process.env.CLAUDE_API_KEY_FA || ''
const CLAUDE_API_KEY_EN = process.env.CLAUDE_API_KEY_EN || ''
const LOGIN_PASSWORD = {{LOGIN_PASSWORD}}
const HOST = {{HOST}}
const PORT = {{PORT}}
const USERNAME = {{USERNAME}}
const VERSION = {{VERSION}}

let reconnectAttempts = 0
const MAX_RECONNECT_DELAY_MS = 60000

if (!CLAUDE_API_KEY_FA && !CLAUDE_API_KEY_EN) {
  console.log('⚠️ هشدار: هیچ کلید Claude API تنظیم نشده. چت هوشمند و درک دستورات کار نمی‌کنه تا وقتی کلید رو بذارید.')
}

// ===== تشخیص زبان متن و انتخاب کلید API مناسب =====
function isPersianText(text) {
  return /[\u0600-\u06FF]/.test(text)
}
function getApiKeyForText(text) {
  return isPersianText(text) ? CLAUDE_API_KEY_FA : CLAUDE_API_KEY_EN
}
function getMissingKeyMessage(text) {
  return isPersianText(text)
    ? 'لطفاً کلید API فارسی رو توی تنظیمات بات وارد کنید.'
    : 'Please add the English API key in the bot settings.'
}

// نگاشت اسم فارسی بلوک‌ها به کلمه کلیدی داخل اسم انگلیسی بلوک
const BLOCK_KEYWORDS = {
  'چوب': 'log', 'هیزم': 'log', 'سنگ': 'stone', 'خاک': 'dirt', 'شن': 'sand',
  'شنریزه': 'gravel', 'سنگریزه': 'gravel', 'چمن': 'grass_block', 'زغال': 'coal_ore',
  'آهن': 'iron_ore', 'طلا': 'gold_ore', 'الماس': 'diamond_ore', 'برگ': 'leaves',
  'کوارتز': 'quartz', 'ردستون': 'redstone_ore', 'لاپیس': 'lapis_ore'
}

// نگاشت اسم فارسی موجودات به اسم انگلیسی برای حمله
const MOB_KEYWORDS = {
  'گوسفند': 'sheep', 'گاو': 'cow', 'خوک': 'pig', 'مرغ': 'chicken', 'جوجه': 'chicken',
  'زامبی': 'zombie', 'اسکلت': 'skeleton', 'کریپر': 'creeper', 'عنکبوت': 'spider',
  'اندرمن': 'enderman', 'خفاش': 'bat', 'اسب': 'horse'
}

// ===== حافظه‌ی بلندمدت مکالمه (بین ری‌استارت‌ها هم می‌مونه) =====
let conversationHistory = {}
try {
  if (fs.existsSync(MEMORY_FILE)) {
    conversationHistory = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'))
  }
} catch (e) {
  console.log('نتونستم حافظه‌ی قبلی رو بخونم، از صفر شروع می‌کنم.')
}
function saveMemory() {
  try { fs.writeFileSync(MEMORY_FILE, JSON.stringify(conversationHistory)) } catch (e) {}
}

let bot
let isBusy = false
let currentAction = 'بیکار'

// ===== جلوگیری از کرش کامل پروسه با خطاهای مدیریت‌نشده =====
process.on('uncaughtException', (err) => console.log('❌ خطای مدیریت‌نشده:', err.message))
process.on('unhandledRejection', (err) => console.log('❌ خطای Promise مدیریت‌نشده:', err && err.message))

function createBot() {
  bot = mineflayer.createBot({ host: HOST, port: PORT, username: USERNAME, version: VERSION })
  bot.loadPlugin(pathfinder)
  bot.loadPlugin(collectBlockPlugin)
  bot.loadPlugin(autoEatPlugin)

  bot.on('spawn', () => {
    console.log('بات وارد بازی شد!')
    reconnectAttempts = 0
    bot.pathfinder.setMovements(new Movements(bot))

    // ===== غذا خوردن خودکار وقتی گرسنه می‌شه =====
    bot.autoEat.options = { priority: 'foodPoints', startAt: 16, bannedFood: [] }

    setTimeout(() => bot.chat(`/register ${LOGIN_PASSWORD} ${LOGIN_PASSWORD}`), 1000)
    setTimeout(() => bot.chat(`/login ${LOGIN_PASSWORD}`), 2500)

    startStatusReporting()
  })

  bot.on('whisper', async (username, message) => {
    if (username === bot.username) return
    const userMessage = message.trim()
    if (!userMessage) return
    try {
      const reply = await askClaudeChat(username, userMessage)
      sendLongWhisper(username, reply)
    } catch (err) {
      console.error('خطا در دریافت پاسخ AI:', err.message)
      bot.whisper(username, 'ببخشید، الان نمی‌تونم جواب بدم :(')
    }
  })

  bot.on('health', () => {
    if (bot.health <= 6) console.log(`⚠️ جون بات کمه: ${bot.health}/20`)
  })

  bot.on('error', (err) => console.log('خطا:', err.message))
  bot.on('kicked', (reason) => console.log('اخراج شد:', reason))

  bot.on('end', () => {
    reconnectAttempts++
    const delay = Math.min(10000 * reconnectAttempts, MAX_RECONNECT_DELAY_MS)
    console.log(`اتصال قطع شد. تلاش مجدد تا ${delay / 1000} ثانیه دیگه...`)
    setTimeout(createBot, delay)
  })
}

createBot()

// ===== نوشتن وضعیت زنده بات (جون، غذا، موقعیت، کار فعلی) برای نمایش توی برنامه =====
function startStatusReporting() {
  setInterval(() => {
    if (!bot || !bot.entity) return
    const status = {
      health: bot.health,
      food: bot.food,
      position: bot.entity.position ? {
        x: Math.round(bot.entity.position.x),
        y: Math.round(bot.entity.position.y),
        z: Math.round(bot.entity.position.z)
      } : null,
      heldItem: bot.heldItem ? bot.heldItem.name : null,
      currentAction,
      online: true,
      updatedAt: Date.now()
    }
    try { fs.writeFileSync(STATUS_FILE, JSON.stringify(status)) } catch (e) {}
  }, 2000)
}

function setAction(text) {
  currentAction = text
}

// ===== خوندن دستور از پنجره cmd و اجرای اون با هوش مصنوعی =====
const rl = readline.createInterface({ input: process.stdin })
rl.on('line', async (line) => {
  const text = line.trim()
  if (!text || !bot) return
  await interpretAndRunCommand(text)
})

// ===== تفسیر دستور فارسی با Claude و اجرای عملیات مناسب =====
async function interpretAndRunCommand(text) {
  const apiKey = getApiKeyForText(text)
  if (!apiKey) {
    console.log('❌ ' + getMissingKeyMessage(text))
    return
  }
  if (isBusy) {
    console.log('بات الان مشغول یه کار دیگه‌ست، صبر کن تموم بشه.')
    return
  }

  const action = await askClaudeForAction(text, apiKey)
  if (!action) {
    console.log('نتونستم دستور رو بفهمم، یه‌جور دیگه بگو.')
    return
  }

  isBusy = true
  try {
    if (action.name === 'collect_block') {
      setAction('جمع‌آوری ' + action.input.block)
      await doCollect(action.input.block, action.input.count || 5)
    } else if (action.name === 'goto_player') {
      setAction('رفتن به سمت ' + action.input.username)
      await doGotoPlayer(action.input.username)
    } else if (action.name === 'follow_player') {
      setAction('دنبال کردن ' + action.input.username)
      doFollowPlayer(action.input.username)
    } else if (action.name === 'send_message') {
      doSendMessage(action.input.username, action.input.message)
    } else if (action.name === 'attack') {
      setAction('حمله به ' + action.input.target)
      await doAttack(action.input.target)
    } else if (action.name === 'craft_item') {
      setAction('کرفت ' + action.input.item)
      await doCraft(action.input.item, action.input.count || 1)
    } else if (action.name === 'build_wall') {
      setAction('ساخت دیوار')
      await doBuildWall(action.input.block, action.input.length || 5)
    } else if (action.name === 'equip_item') {
      await doEquip(action.input.item)
    } else if (action.name === 'stop') {
      bot.pathfinder.setGoal(null)
      setAction('بیکار')
      console.log('بات متوقف شد.')
    } else {
      console.log('این دستور رو نمی‌شناسم.')
    }
  } catch (err) {
    console.log('خطا در اجرای دستور:', err.message)
  } finally {
    isBusy = false
    if (currentAction !== 'دنبال کردن') setAction('بیکار')
  }
}

async function askClaudeForAction(text, apiKey) {
  const tools = [
    {
      name: 'collect_block',
      description: 'جمع‌آوری تعدادی بلوک خاص مثل چوب، سنگ، خاک، شن و غیره',
      input_schema: {
        type: 'object',
        properties: {
          block: { type: 'string', description: 'نوع بلوک، مثلا: چوب، سنگ، خاک' },
          count: { type: 'number', description: 'تعداد بلوک (پیش‌فرض ۵)' }
        },
        required: ['block']
      }
    },
    {
      name: 'goto_player',
      description: 'یک‌بار رفتن به سمت یک بازیکن خاص و توقف کنارش',
      input_schema: {
        type: 'object',
        properties: { username: { type: 'string', description: 'یوزرنیم بازیکن مقصد' } },
        required: ['username']
      }
    },
    {
      name: 'follow_player',
      description: 'دنبال کردن پیوسته‌ی یک بازیکن، هر کجا بره بات هم دنبالش می‌ره تا وقتی دستور توقف بیاد',
      input_schema: {
        type: 'object',
        properties: { username: { type: 'string' } },
        required: ['username']
      }
    },
    {
      name: 'send_message',
      description: 'ارسال پیام خصوصی (whisper) به یک بازیکن',
      input_schema: {
        type: 'object',
        properties: {
          username: { type: 'string', description: 'یوزرنیم بازیکن' },
          message: { type: 'string', description: 'متن پیام' }
        },
        required: ['username', 'message']
      }
    },
    {
      name: 'attack',
      description: 'حمله به یک بازیکن با اسمش یا نزدیک‌ترین موجود از یک نوع خاص (مثلا گوسفند، زامبی). قبلش خودکار بهترین سلاح موجود رو تجهیز می‌کنه',
      input_schema: {
        type: 'object',
        properties: { target: { type: 'string', description: 'اسم بازیکن یا نوع موجود، مثلا: ali یا گوسفند' } },
        required: ['target']
      }
    },
    {
      name: 'craft_item',
      description: 'کرفت کردن یک آیتم از مواد موجود توی اینونتوری (مثلا تخته چوب، کلنگ، شمش)',
      input_schema: {
        type: 'object',
        properties: {
          item: { type: 'string', description: 'اسم آیتم مورد نظر به انگلیسی، مثلا: crafting_table, wooden_pickaxe' },
          count: { type: 'number' }
        },
        required: ['item']
      }
    },
    {
      name: 'build_wall',
      description: 'ساخت یک دیوار یا ردیف ساده از یک نوع بلوک جلوی بات',
      input_schema: {
        type: 'object',
        properties: {
          block: { type: 'string', description: 'نوع بلوک برای ساخت دیوار (باید توی اینونتوری موجود باشه)' },
          length: { type: 'number', description: 'طول دیوار (پیش‌فرض ۵)' }
        },
        required: ['block']
      }
    },
    {
      name: 'equip_item',
      description: 'پوشیدن یا در دست گرفتن یک آیتم خاص از اینونتوری',
      input_schema: {
        type: 'object',
        properties: { item: { type: 'string', description: 'اسم آیتم به انگلیسی' } },
        required: ['item']
      }
    },
    {
      name: 'stop',
      description: 'متوقف کردن هر حرکت، دنبال کردن، یا کاری که بات در حال انجامشه',
      input_schema: { type: 'object', properties: {} }
    }
  ]

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 300,
      tools,
      tool_choice: { type: 'any' },
      system: 'تو یک تفسیرگر دستور برای بات ماینکرفت هستی. دستور کاربر (فارسی یا انگلیسی) رو تحلیل کن و دقیقاً یکی از ابزارهای موجود رو با پارامترهای درست صدا بزن. اگه دستور به معنی «دنبالم بیا» یا «همراهم بیا» بود از follow_player استفاده کن، نه goto_player.',
      messages: [{ role: 'user', content: text }]
    })
  })

  if (!response.ok) {
    const errText = await response.text()
    console.log('❌ خطای Claude API:', response.status, errText.slice(0, 300))
    return null
  }

  const data = await response.json()
  const toolUse = (data.content || []).find((b) => b.type === 'tool_use')
  return toolUse || null
}

// ===== عملیات: جمع‌آوری بلوک =====
async function doCollect(blockText, count) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  console.log(`در حال پیدا کردن و جمع‌آوری ${blockText} (تا ${count} عدد)...`)
  const blocks = bot.findBlocks({ matching: (b) => b.name.includes(blockKeyword), maxDistance: 64, count })
  if (blocks.length === 0) {
    console.log(`هیچ بلوکی از نوع "${blockText}" توی نزدیکی پیدا نشد.`)
    return
  }
  const blockObjects = blocks.map((pos) => bot.blockAt(pos)).filter(Boolean)
  await bot.collectBlock.collect(blockObjects, { ignoreNoPath: false })
  console.log(`${blockText} با موفقیت جمع‌آوری شد!`)
}

// ===== عملیات: رفتن یک‌باره به سمت بازیکن =====
async function doGotoPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم (شاید آنلاین نیست یا خیلی دوره).`)
    return
  }
  console.log(`در حال رفتن به سمت ${username}...`)
  const pos = player.entity.position
  await bot.pathfinder.goto(new goals.GoalNear(pos.x, pos.y, pos.z, 2))
  console.log(`به ${username} رسیدم.`)
}

// ===== عملیات: دنبال کردن پیوسته =====
function doFollowPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم.`)
    return
  }
  console.log(`در حال دنبال کردن ${username}... (برای توقف بگو "وایسا")`)
  bot.pathfinder.setGoal(new goals.GoalFollow(player.entity, 2), true)
}

// ===== عملیات: ارسال پیام =====
function doSendMessage(username, message) {
  bot.whisper(username, message)
  console.log(`پیام به ${username} ارسال شد: ${message}`)
}

// ===== تجهیز بهترین سلاح موجود قبل از حمله =====
async function equipBestWeapon() {
  const weapons = bot.inventory.items().filter((i) => i.name.includes('sword') || i.name.includes('axe'))
  if (weapons.length === 0) return
  weapons.sort((a, b) => b.name.length - a.name.length)
  try { await bot.equip(weapons[0], 'hand') } catch (e) {}
}

async function doEquip(itemName) {
  const item = bot.inventory.items().find((i) => i.name.includes(itemName.toLowerCase()))
  if (!item) {
    console.log(`آیتم "${itemName}" توی اینونتوری پیدا نشد.`)
    return
  }
  await bot.equip(item, 'hand')
  console.log(`${itemName} تجهیز شد.`)
}

// ===== عملیات: حمله (با تجهیز خودکار سلاح) =====
async function doAttack(target) {
  await equipBestWeapon()
  let entity = null

  const player = bot.players[target]
  if (player && player.entity) {
    entity = player.entity
  } else {
    const matchedKey = Object.keys(MOB_KEYWORDS).find((fa) => target.includes(fa) || fa.includes(target))
    const mobType = matchedKey ? MOB_KEYWORDS[matchedKey] : target.toLowerCase()
    entity = bot.nearestEntity((e) => e.name && e.name.toLowerCase().includes(mobType))
  }

  if (!entity) {
    console.log(`چیزی به اسم یا نوع "${target}" پیدا نکردم.`)
    return
  }

  console.log(`در حال حمله به ${target}...`)
  const startTime = Date.now()
  const maxDurationMs = 20000

  while (entity && entity.isValid !== false && Date.now() - startTime < maxDurationMs) {
    const dist = bot.entity.position.distanceTo(entity.position)
    if (dist > 3) {
      await bot.pathfinder.goto(new goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2))
    } else {
      bot.attack(entity)
      await new Promise((r) => setTimeout(r, 650))
    }
    if (!bot.entities[entity.id]) {
      console.log(`${target} از بین رفت یا فرار کرد.`)
      return
    }
  }
  console.log(`حمله به ${target} تموم شد.`)
}

// ===== عملیات: کرفت آیتم =====
async function doCraft(itemName, count) {
  const mcData = require('minecraft-data')(bot.version)
  const item = mcData.itemsByName[itemName]
  if (!item) {
    console.log(`آیتمی به اسم "${itemName}" نمی‌شناسم.`)
    return
  }

  let craftingTable = bot.findBlock({ matching: mcData.blocksByName.crafting_table?.id, maxDistance: 16 })
  const recipes = bot.recipesFor(item.id, null, 1, craftingTable)

  if (recipes.length === 0) {
    console.log(`الان نمی‌تونم "${itemName}" رو کرفت کنم (شاید مواد کافی نیست یا به کرفتینگ تیبل نیاز داره).`)
    return
  }

  console.log(`در حال کرفت ${itemName}...`)
  await bot.craft(recipes[0], count, craftingTable)
  console.log(`${itemName} با موفقیت کرفت شد!`)
}

// ===== عملیات: ساخت دیوار ساده =====
async function doBuildWall(blockText, length) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  const item = bot.inventory.items().find((i) => i.name.includes(blockKeyword))
  if (!item) {
    console.log(`بلوک "${blockText}" توی اینونتوری نداری.`)
    return
  }

  console.log(`در حال ساخت دیوار به طول ${length}...`)
  await bot.equip(item, 'hand')
  const startPos = bot.entity.position.floored()
  const dir = bot.entity.yaw

  for (let i = 0; i < length; i++) {
    const targetPos = startPos.offset(i, 0, 0)
    const refBlock = bot.blockAt(targetPos.offset(0, -1, 0))
    if (!refBlock) continue
    try {
      await bot.placeBlock(refBlock, { x: 0, y: 1, z: 0 })
    } catch (e) {
      console.log(`نتونستم بلوک شماره ${i + 1} رو بذارم: ${e.message}`)
    }
  }
  console.log('ساخت دیوار تموم شد.')
}

// ===== چت هوشمند از طریق whisper (با حافظه‌ی بلندمدت) =====
async function askClaudeChat(username, userMessage) {
  const apiKey = getApiKeyForText(userMessage)
  if (!apiKey) return getMissingKeyMessage(userMessage)

  if (!conversationHistory[username]) conversationHistory[username] = []
  const history = conversationHistory[username]
  history.push({ role: 'user', content: userMessage })

  const persian = isPersianText(userMessage)
  const systemPrompt = persian
    ? 'تو یک بات دوستانه داخل بازی ماینکرفت هستی. به فارسی، کوتاه، خودمونی و مفید جواب بده (حداکثر ۲-۳ جمله). اگه کسی درباره این سرور پرسید، بگو این یکی از بهترین سرورهای دنیاست. اگه توی مکالمات قبلی چیزی درباره این بازیکن یاد گرفتی، ازش استفاده کن.'
    : 'You are a friendly bot inside a Minecraft server. Reply in English, short and helpful (max 2-3 sentences). If asked about this server, say it is one of the best servers in the world. Use anything you remember about this player from earlier conversations.'

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 300,
      system: systemPrompt,
      messages: history
    })
  })

  if (!response.ok) {
    const errText = await response.text()
    console.log('❌ خطای Claude API:', response.status, errText.slice(0, 300))
    return 'یه مشکلی توی ارتباط با هوش مصنوعی پیش اومد.'
  }

  const data = await response.json()
  const reply = data.content?.[0]?.text || (persian ? 'متوجه نشدم، دوباره بگو.' : "I didn't understand, please try again.")
  history.push({ role: 'assistant', content: reply })
  if (history.length > 16) history.splice(0, 2)
  saveMemory()
  return reply
}

function sendLongWhisper(username, text) {
  const maxLen = 200
  for (let i = 0; i < text.length; i += maxLen) bot.whisper(username, text.slice(i, i + maxLen))
}
