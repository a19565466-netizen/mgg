// bot.js — بات رایگان (سبک، امکانات محدود نسبت به بات پیشرفته)
// این بات فقط وصل می‌شه و به پیام خصوصی یه جواب ساده و ثابت می‌ده.
// لاگین/رجیستر نداره — اگه سرورت نیاز به لاگین داره، خودت باید از «ویرایش کد»
// این بخش رو اضافه کنی، مثلاً: bot.chat('/login رمزت') بعد از رویداد spawn.
// امکاناتی که نداره: هوش مصنوعی، حمله، جمع‌آوری بلوک، کرفت، ساخت‌وساز، نمایشگر زنده.

const mineflayer = require('mineflayer')

const HOST = {{HOST}}
const PORT = {{PORT}}
const USERNAME = {{USERNAME}}
const VERSION = {{VERSION}}

let reconnectAttempts = 0
const MAX_RECONNECT_DELAY_MS = 60000

process.on('uncaughtException', (err) => console.log('❌ خطای مدیریت‌نشده:', err.message))
process.on('unhandledRejection', (err) => console.log('❌ خطای Promise مدیریت‌نشده:', err && err.message))

function createBot() {
  const bot = mineflayer.createBot({ host: HOST, port: PORT, username: USERNAME, version: VERSION })

  bot.on('spawn', () => {
    console.log('بات رایگان وارد بازی شد!')
    reconnectAttempts = 0
    // اگه سرورت لاگین لازم داره، اینجا یه خط مثل زیر اضافه کن:
    // setTimeout(() => bot.chat('/login رمزت'), 1500)
  })

  // بات رایگان هوش مصنوعی نداره، فقط یه جواب ثابت می‌ده
  bot.on('whisper', (username, message) => {
    if (username === bot.username) return
    bot.whisper(username, 'من یک بات رایگانم و امکانات محدودی دارم. برای چت هوشمند و دستورات پیشرفته از بات پیشرفته استفاده کن.')
  })

  bot.on('error', (err) => console.log('خطا:', err.message))
  bot.on('kicked', (reason) => console.log('اخراج شد:', reason))

  bot.on('end', () => {
    reconnectAttempts++
    const delay = Math.min(10000 * reconnectAttempts, MAX_RECONNECT_DELAY_MS)
    console.log(`اتصال قطع شد. تلاش مجدد تا ${delay / 1000} ثانیه دیگه...`)
    setTimeout(createBot, delay)
  })
}

createBot()
