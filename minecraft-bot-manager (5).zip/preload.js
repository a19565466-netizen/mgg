const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('api', {
  createBot: (data) => ipcRenderer.invoke('create-bot', data),
  getBots: () => ipcRenderer.invoke('get-bots'),
  startBot: (id) => ipcRenderer.invoke('start-bot', id),
  stopBot: (id) => ipcRenderer.invoke('stop-bot', id),
  deleteBot: (id) => ipcRenderer.invoke('delete-bot', id),
  sendCommand: (id, text) => ipcRenderer.invoke('send-command', { id, text }),
  getBotCode: (id) => ipcRenderer.invoke('get-bot-code', id),
  saveBotCode: (id, code) => ipcRenderer.invoke('save-bot-code', { id, code }),
  openBotFolder: (id) => ipcRenderer.invoke('open-bot-folder', id),
  checkNode: () => ipcRenderer.invoke('check-node'),
  getBotStatus: (id) => ipcRenderer.invoke('get-bot-status', id),
  getBotSettings: (id) => ipcRenderer.invoke('get-bot-settings', id),
  saveBotSettings: (id, data) => ipcRenderer.invoke('save-bot-settings', { id, data }),

  onBotLog: (cb) => ipcRenderer.on('bot-log', (e, data) => cb(data)),
  onInstallLog: (cb) => ipcRenderer.on('install-log', (e, data) => cb(data)),
  onBotStatus: (cb) => ipcRenderer.on('bot-status', (e, data) => cb(data)),
  onNodeInstallLog: (cb) => ipcRenderer.on('node-install-log', (e, data) => cb(data))
})
