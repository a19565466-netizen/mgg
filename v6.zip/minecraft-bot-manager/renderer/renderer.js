let bots = []
let activeId = null

const botListEl = document.getElementById('botList')
const emptyState = document.getElementById('emptyState')
const botPanel = document.getElementById('botPanel')
const botTitle = document.getElementById('botTitle')
const consoleEl = document.getElementById('console')

async function refreshBots() {
  bots = await window.api.getBots()
  renderList()
}

function renderList() {
  botListEl.innerHTML = ''
  for (const b of bots) {
    const div = document.createElement('div')
    div.className = 'bot-item' + (b.id === activeId ? ' active' : '')
    div.innerHTML = `<span>${b.name}</span><span class="dot ${b.running ? 'on' : 'off'}"></span>`
    div.onclick = () => selectBot(b.id)
    botListEl.appendChild(div)
  }
}

function selectBot(id) {
  activeId = id
  const b = bots.find((x) => x.id === id)
  emptyState.classList.add('hidden')
  botPanel.classList.remove('hidden')
  botTitle.textContent = b.name + (b.running ? ' (روشن)' : ' (خاموش)')
  consoleEl.textContent = ''
  document.getElementById('controlBtn').classList.toggle('hidden', !['viewer', 'survival', 'bedwars'].includes(b.botType))
  document.getElementById('playlistBtn').classList.toggle('hidden', b.botType !== 'voicechat')
  const cmdInput = document.getElementById('commandInput')
  cmdInput.placeholder = (b.botType === 'viewer')
    ? 'چت عادی بنویس، یا برای حرکت: w a s d، jump، sprint، stop'
    : 'دستور بده، مثلاً: 5 تا چوب جمع کن'
  renderList()
}

// ===== نمایش زنده وضعیت بات (جون، غذا، موقعیت، کار فعلی) =====
setInterval(async () => {
  if (!activeId) return
  const status = await window.api.getBotStatus(activeId)
  if (!status) return
  document.getElementById('statHealth').textContent = `❤️ ${status.health ?? '--'}/20`
  document.getElementById('statFood').textContent = `🍗 ${status.food ?? '--'}/20`
  document.getElementById('statPos').textContent = status.position
    ? `📍 ${status.position.x}, ${status.position.y}, ${status.position.z}`
    : '📍 --'
  document.getElementById('statAction').textContent = `⚙️ ${status.currentAction || '--'}`
}, 2000)

// ===== دکمه‌های کنترل بات =====
document.getElementById('startBtn').onclick = async () => {
  if (!activeId) return
  await window.api.startBot(activeId)
  await refreshBots()
  selectBot(activeId)
}
document.getElementById('stopBtn').onclick = async () => {
  if (!activeId) return
  await window.api.stopBot(activeId)
  await refreshBots()
  selectBot(activeId)
}
document.getElementById('restartBtn').onclick = async () => {
  if (!activeId) return
  await window.api.stopBot(activeId)
  setTimeout(async () => {
    await window.api.startBot(activeId)
    await refreshBots()
    selectBot(activeId)
  }, 800)
}
document.getElementById('deleteBtn').onclick = async () => {
  if (!activeId) return
  if (!confirm('مطمئنی می‌خوای این بات رو کامل حذف کنی؟')) return
  await window.api.deleteBot(activeId)
  activeId = null
  botPanel.classList.add('hidden')
  emptyState.classList.remove('hidden')
  await refreshBots()
}

// ===== کنترل زنده با کیبورد/موس =====
const controlModal = document.getElementById('controlModal')
const controlPad = document.getElementById('controlPad')
let ctrlState = { forward: false, back: false, left: false, right: false, jump: false, sprint: false, yaw: 0, pitch: 0 }
let controlActive = false
let controlSendTimer = null
const CONTROL_KEY_MAP = { KeyW: 'forward', KeyS: 'back', KeyA: 'left', KeyD: 'right', Space: 'jump', ShiftLeft: 'sprint', ShiftRight: 'sprint' }

document.getElementById('controlBtn').onclick = async () => {
  if (!activeId) return
  const settings = await window.api.getBotSettings(activeId)
  const port = settings && settings.viewerPort
  const frame = document.getElementById('viewerFrame')
  frame.src = port ? `http://localhost:${port}` : 'about:blank'
  controlModal.classList.remove('hidden')
}
document.getElementById('reloadViewer').onclick = () => {
  const frame = document.getElementById('viewerFrame')
  if (frame.src && frame.src !== 'about:blank') frame.src = frame.src
}
document.getElementById('closeControl').onclick = () => {
  if (document.pointerLockElement) document.exitPointerLock()
  controlModal.classList.add('hidden')
}
controlPad.addEventListener('click', () => controlPad.requestPointerLock())

document.addEventListener('pointerlockchange', () => {
  controlActive = document.pointerLockElement === controlPad
  controlPad.classList.toggle('active', controlActive)
  controlPad.textContent = controlActive ? '🎮 در حال کنترل... (Esc برای خروج)' : 'برای شروع کنترل، اینجا کلیک کن'
  if (controlActive) {
    if (controlSendTimer) clearInterval(controlSendTimer)
    controlSendTimer = setInterval(sendControlState, 50)
  } else {
    if (controlSendTimer) { clearInterval(controlSendTimer); controlSendTimer = null }
    ctrlState.forward = ctrlState.back = ctrlState.left = ctrlState.right = ctrlState.jump = ctrlState.sprint = false
    sendControlState()
  }
})

document.addEventListener('mousemove', (e) => {
  if (!controlActive) return
  const sensitivity = 0.0025
  ctrlState.yaw -= e.movementX * sensitivity
  ctrlState.pitch -= e.movementY * sensitivity
  const maxPitch = Math.PI / 2 - 0.05
  if (ctrlState.pitch > maxPitch) ctrlState.pitch = maxPitch
  if (ctrlState.pitch < -maxPitch) ctrlState.pitch = -maxPitch
})
document.addEventListener('keydown', (e) => {
  if (!controlActive) return
  const field = CONTROL_KEY_MAP[e.code]
  if (field) { ctrlState[field] = true; e.preventDefault() }
})
document.addEventListener('keyup', (e) => {
  if (!controlActive) return
  const field = CONTROL_KEY_MAP[e.code]
  if (field) { ctrlState[field] = false; e.preventDefault() }
})
function sendControlState() {
  if (!activeId) return
  window.api.sendControl(activeId, ctrlState)
}

// ===== خروجی/ورودی گرفتن از تنظیمات بات‌ها =====
document.getElementById('exportBotsBtn').onclick = async () => {
  const result = await window.api.exportBots()
  if (result && result.ok) alert('خروجی ذخیره شد: ' + result.path)
}
document.getElementById('importBotsBtn').onclick = async () => {
  const result = await window.api.importBots()
  if (result && result.ok) {
    alert(`${result.count} بات وارد شد. اگه پکیج‌هاشون کامل نصب نشده باشه، از «نصب مجدد پکیج‌ها» استفاده کن.`)
    await refreshBots()
  } else if (result && result.error) {
    alert(result.error)
  }
}

// ===== مودال لیست‌پخش ویس‌چت =====
const playlistModal = document.getElementById('playlistModal')
document.getElementById('playlistBtn').onclick = () => {
  if (!activeId) return
  const b = bots.find((x) => x.id === activeId)
  if (!b) return
  document.getElementById('pl_default').value = b.defaultSong || ''
  document.getElementById('pl_playlist').value = (b.playlist || []).join('\n')
  document.getElementById('pl_duration').value = Math.round((b.trackDurationMs || 180000) / 1000)
  playlistModal.classList.remove('hidden')
}
document.getElementById('cancelPlaylist').onclick = () => playlistModal.classList.add('hidden')
document.getElementById('savePlaylist').onclick = async () => {
  if (!activeId) return
  const playlist = document.getElementById('pl_playlist').value.split('\n').map((s) => s.trim()).filter(Boolean)
  const defaultSong = document.getElementById('pl_default').value.trim()
  const trackDurationMs = (Number(document.getElementById('pl_duration').value) || 180) * 1000
  await window.api.updatePlaylist(activeId, { playlist, defaultSong, trackDurationMs })
  playlistModal.classList.add('hidden')
  await refreshBots()
  alert('ذخیره شد. اگه بات روشنه، برای اعمال تغییرات ری‌استارتش کن.')
}

document.getElementById('reinstallBtn').onclick = async () => {
  if (!activeId) return
  if (!confirm('پکیج‌های این بات دوباره نصب می‌شن. ادامه بدم؟')) return
  const result = await window.api.reinstallBot(activeId)
  alert(result.ok ? 'نصب مجدد با موفقیت انجام شد.' : 'نصب مجدد هم با مشکل مواجه شد — اتصال اینترنتت رو چک کن.')
}

// ===== ارسال دستور =====
document.getElementById('sendCommandBtn').onclick = sendCommand
document.getElementById('commandInput').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendCommand()
})
function sendCommand() {
  const input = document.getElementById('commandInput')
  const text = input.value.trim()
  if (!text || !activeId) return
  window.api.sendCommand(activeId, text)
  input.value = ''
}

// ===== لاگ‌های زنده =====
window.api.onBotLog(({ id, line }) => {
  if (id !== activeId) return
  consoleEl.textContent += line
  consoleEl.scrollTop = consoleEl.scrollHeight
})
window.api.onBotStatus(async () => {
  await refreshBots()
  if (activeId) selectBot(activeId)
})

// ===== مودال انتخاب نوع بات =====
let pendingBotType = 'mobile'
let pendingUnlockPassword = ''
const ADVANCED_BOT_PASSWORD = 'moz@555' // فقط یه قفل محلی ساده، نه یه لایه‌ی امنیتی واقعی
const BEDWARS_BOT_PASSWORD = 'llbbdd'
const BOT_CAP_LIMIT = 20
const typeModal = document.getElementById('typeModal')
const passwordModal = document.getElementById('passwordModal')

document.getElementById('newBotBtn').onclick = () => {
  typeModal.classList.remove('hidden')
}
document.getElementById('cancelType').onclick = () => typeModal.classList.add('hidden')
document.getElementById('typeFreeBtn').onclick = () => {
  pendingBotType = 'free'
  pendingUnlockPassword = ''
  typeModal.classList.add('hidden')
  openCreateModal()
}
document.getElementById('typeSingleBtn').onclick = () => {
  typeModal.classList.add('hidden')
  requireCapPasswordIfNeeded('mobile')
}
document.getElementById('typeSurvivalBtn').onclick = () => {
  typeModal.classList.add('hidden')
  requireCapPasswordIfNeeded('survival')
}
document.getElementById('typeViewerBtn').onclick = () => {
  typeModal.classList.add('hidden')
  askForPassword(ADVANCED_BOT_PASSWORD, () => {
    pendingBotType = 'viewer'
    openCreateModal()
  })
}
document.getElementById('typeBedwarsBtn').onclick = () => {
  typeModal.classList.add('hidden')
  askForPassword(BEDWARS_BOT_PASSWORD, () => {
    pendingBotType = 'bedwars'
    openCreateModal()
  })
}
document.getElementById('typeVoicechatBtn').onclick = () => {
  pendingBotType = 'voicechat'
  pendingUnlockPassword = ''
  typeModal.classList.add('hidden')
  openCreateModal()
}

// ===== محدودیت ۲۰ تایی برای ربات متحرک/سروایول: بعدش رمز لازمه =====
function requireCapPasswordIfNeeded(type) {
  const limitedCount = bots.filter((b) => b.botType === 'mobile' || b.botType === 'survival').length
  if (limitedCount < BOT_CAP_LIMIT) {
    pendingBotType = type
    pendingUnlockPassword = ''
    openCreateModal()
    return
  }
  askForPassword(ADVANCED_BOT_PASSWORD, () => {
    pendingBotType = type
    openCreateModal()
  })
}

// ===== یه مودال رمز واحد که با یه کال‌بک و رمز مشخص کار می‌کنه =====
let pendingPasswordCallback = null
let pendingExpectedPassword = ''
function askForPassword(expectedPassword, onSuccess) {
  pendingExpectedPassword = expectedPassword
  pendingPasswordCallback = onSuccess
  document.getElementById('pw_input').value = ''
  passwordModal.classList.remove('hidden')
}
document.getElementById('cancelPassword').onclick = () => passwordModal.classList.add('hidden')
document.getElementById('confirmPassword').onclick = () => {
  const val = document.getElementById('pw_input').value
  if (val !== pendingExpectedPassword) {
    alert('رمز اشتباهه.')
    return
  }
  pendingUnlockPassword = val
  passwordModal.classList.add('hidden')
  if (pendingPasswordCallback) pendingPasswordCallback()
}
document.getElementById('pw_input').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('confirmPassword').click()
})

// ===== مودال ساخت بات جدید =====
const createModal = document.getElementById('createModal')
function openCreateModal() {
  ;['f_name','f_host','f_port','f_version','f_username','f_password','f_joincommand'].forEach((id) => document.getElementById(id).value = '')
  document.getElementById('f_autostart').checked = false
  document.getElementById('installProgressWrap').classList.add('hidden')
  document.getElementById('installProgressFill').style.width = '0%'
  document.getElementById('installProgressText').textContent = '0%'
  const titles = {
    mobile: 'ساخت بات جدید (ربات متحرک)',
    viewer: 'ساخت بات جدید (روبات پیشرفته)',
    survival: 'ساخت بات جدید (سروایول خودکار)',
    free: 'ساخت بات جدید (بات رایگان)',
    bedwars: 'ساخت بات جدید (Bedwars - آزمایشی)',
    voicechat: 'ساخت بات جدید (ویس‌چت)'
  }
  createModal.querySelector('h3').textContent = titles[pendingBotType] || titles.mobile
  document.getElementById('passwordFieldRow').classList.toggle('hidden', pendingBotType === 'free')
  createModal.classList.remove('hidden')
}
document.getElementById('cancelCreate').onclick = () => createModal.classList.add('hidden')

document.getElementById('saveCreate').onclick = async () => {
  const data = {
    name: document.getElementById('f_name').value || 'بات جدید',
    host: document.getElementById('f_host').value,
    port: document.getElementById('f_port').value,
    version: document.getElementById('f_version').value,
    username: document.getElementById('f_username').value,
    password: document.getElementById('f_password').value,
    autoStart: document.getElementById('f_autostart').checked,
    botType: pendingBotType,
    unlockPassword: pendingUnlockPassword,
    joinCommand: document.getElementById('f_joincommand').value
  }
  if (!data.host || !data.username) {
    alert('حداقل آی‌پی سرور و یوزرنیم رو وارد کن.')
    return
  }
  const progressWrap = document.getElementById('installProgressWrap')
  const progressFill = document.getElementById('installProgressFill')
  const progressText = document.getElementById('installProgressText')
  progressWrap.classList.remove('hidden')
  progressFill.style.width = '0%'
  progressText.textContent = '0%'

  const removeListener = window.api.onInstallLog(({ id, percent, line }) => {
    if (typeof percent === 'number') {
      progressFill.style.width = percent + '%'
      progressText.textContent = percent + '%' + (line ? ' — ' + line.trim() : '')
    }
  })

  const result = await window.api.createBot(data)
  if (result && result.error) {
    alert(result.error)
    progressWrap.classList.add('hidden')
    return
  }
  await refreshBots()
  if (result && result.installOk === false) {
    alert('بات ساخته شد ولی نصب پکیج‌ها کامل نبود. از دکمه‌ی «نصب مجدد پکیج‌ها» توی پنل بات استفاده کن.')
  }
  setTimeout(() => createModal.classList.add('hidden'), 500)
}

// ===== مودال ویرایش کد =====
const editModal = document.getElementById('editModal')
document.getElementById('editBtn').onclick = async () => {
  if (!activeId) return
  const code = await window.api.getBotCode(activeId)
  document.getElementById('codeEditor').value = code
  editModal.classList.remove('hidden')
}
document.getElementById('cancelEdit').onclick = () => editModal.classList.add('hidden')
document.getElementById('saveEdit').onclick = async () => {
  const code = document.getElementById('codeEditor').value
  await window.api.saveBotCode(activeId, code)
  editModal.classList.add('hidden')
  alert('ذخیره شد. برای اعمال تغییرات، بات رو ری‌استارت کن.')
}

// ===== مودال ویرایش تنظیمات (آی‌پی، اسم، لاگین، کلیدهای API) =====
const settingsModal = document.getElementById('settingsModal')
document.getElementById('editSettingsBtn').onclick = async () => {
  if (!activeId) return
  const s = await window.api.getBotSettings(activeId)
  if (!s) return
  document.getElementById('s_name').value = s.name || ''
  document.getElementById('s_host').value = s.host || ''
  document.getElementById('s_port').value = s.port || ''
  document.getElementById('s_version').value = s.version || ''
  document.getElementById('s_username').value = s.username || ''
  document.getElementById('s_password').value = s.password || ''
  settingsModal.classList.remove('hidden')
}
document.getElementById('cancelSettings').onclick = () => settingsModal.classList.add('hidden')
document.getElementById('saveSettings').onclick = async () => {
  const data = {
    name: document.getElementById('s_name').value,
    host: document.getElementById('s_host').value,
    port: document.getElementById('s_port').value,
    version: document.getElementById('s_version').value,
    username: document.getElementById('s_username').value,
    password: document.getElementById('s_password').value
  }
  await window.api.saveBotSettings(activeId, data)
  await refreshBots()
  selectBot(activeId)
  settingsModal.classList.add('hidden')
  alert('تنظیمات ذخیره شد. برای اعمال تغییرات، بات رو ری‌استارت کن.')
}

refreshBots()

// ===== چک کردن و نصب خودکار Node.js موقع باز شدن برنامه =====
const nodeOverlay = document.getElementById('nodeOverlay')
const nodeInstallLog = document.getElementById('nodeInstallLog')
const newBotBtn = document.getElementById('newBotBtn')

window.api.onNodeInstallLog(({ line }) => {
  nodeOverlay.classList.remove('hidden')
  nodeInstallLog.textContent += line + '\n'
  nodeInstallLog.scrollTop = nodeInstallLog.scrollHeight
})

async function ensureNode() {
  newBotBtn.disabled = true
  const result = await window.api.checkNode()
  newBotBtn.disabled = false
  nodeOverlay.classList.add('hidden')
  if (!result.installed) {
    alert('نصب خودکار Node.js موفق نبود. لطفاً دستی از nodejs.org نصب کنید و برنامه رو دوباره باز کنید.')
  }
}
ensureNode()

// ===== حذف اسپلش‌اسکرین بعد از آماده شدن برنامه =====
const splashScreen = document.getElementById('splashScreen')
setTimeout(() => {
  splashScreen.classList.add('fade-out')
  setTimeout(() => splashScreen.remove(), 700)
}, 1500)

// ===== دکمه‌ی «آماده‌سازی سیستم» — نصب دستی و فوری Node.js/Python/Build Tools =====
document.getElementById('systemReadyBtn').onclick = async () => {
  nodeInstallLog.textContent = ''
  nodeOverlay.classList.remove('hidden')
  const result = await window.api.ensureSystemReady()
  if (result.ok) {
    setTimeout(() => nodeOverlay.classList.add('hidden'), 1500)
  }
}
