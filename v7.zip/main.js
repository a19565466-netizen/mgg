const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron')
const path = require('path')
const fs = require('fs')
const https = require('https')
const os = require('os')
const { spawn, spawnSync } = require('child_process')

const botsDir = path.join(app.getPath('userData'), 'bots')
const storeFile = path.join(app.getPath('userData'), 'bots.json')
if (!fs.existsSync(botsDir)) fs.mkdirSync(botsDir, { recursive: true })

const processes = new Map() // id -> child process
let mainWindow

function loadStore() {
  if (!fs.existsSync(storeFile)) return []
  try { return JSON.parse(fs.readFileSync(storeFile, 'utf-8')) } catch { return [] }
}
function saveStore(list) {
  fs.writeFileSync(storeFile, JSON.stringify(list, null, 2))
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    icon: path.join(__dirname, 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true
    }
  })
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))
}

app.whenReady().then(() => {
  createWindow()
  if (process.platform !== 'darwin') {
    app.setAppUserModelId('Minecraft Bot Manager')
  }
})
app.on('window-all-closed', () => {
  // موقع بستن برنامه، همه بات‌های در حال اجرا هم متوقف می‌شن
  for (const proc of processes.values()) proc.kill()
  if (process.platform !== 'darwin') app.quit()
})

// ===== چک کردن و نصب خودکار Node.js اگه نصب نبود =====
function isNodeInstalled() {
  try {
    const result = spawnSync('node', ['--version'], { shell: true })
    return result.status === 0
  } catch {
    return false
  }
}

function fetchJson(url) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'minecraft-bot-manager' } }, (res) => {
      let data = ''
      res.on('data', (chunk) => (data += chunk))
      res.on('end', () => {
        try { resolve(JSON.parse(data)) } catch (e) { reject(e) }
      })
    }).on('error', reject)
  })
}

function downloadFile(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, destPath, onProgress).then(resolve, reject)
      }
      const total = parseInt(res.headers['content-length'] || '0', 10)
      let downloaded = 0
      const fileStream = fs.createWriteStream(destPath)
      res.on('data', (chunk) => {
        downloaded += chunk.length
        if (total) onProgress(Math.round((downloaded / total) * 100))
      })
      res.pipe(fileStream)
      fileStream.on('finish', () => fileStream.close(resolve))
      fileStream.on('error', reject)
    }).on('error', reject)
  })
}

async function installNodeAutomatically(sendLog) {
  sendLog('در حال بررسی آخرین نسخه‌ی Node.js...')
  const index = await fetchJson('https://nodejs.org/dist/index.json')
  const lts = index.find((v) => v.lts)
  const version = lts.version // مثلاً v22.14.0
  const arch = os.arch() === 'x64' ? 'x64' : os.arch() === 'arm64' ? 'arm64' : 'x86'
  const fileName = `node-${version}-${arch}.msi`
  const url = `https://nodejs.org/dist/${version}/${fileName}`
  const destPath = path.join(os.tmpdir(), fileName)

  sendLog(`در حال دانلود Node.js ${version}...`)
  await downloadFile(url, destPath, (percent) => sendLog(`دانلود: ${percent}%`, true))

  sendLog('در حال نصب Node.js روی سیستم (ممکنه یه پنجره‌ی تایید ویندوز باز بشه)...')
  await new Promise((resolve, reject) => {
    const install = spawn('msiexec', ['/i', destPath, '/qb', '/norestart'], { shell: true })
    install.on('close', (code) => (code === 0 ? resolve() : reject(new Error('کد خروجی نصب: ' + code))))
    install.on('error', reject)
  })

  // مسیر پیش‌فرض نصب رو به PATH همین پروسه اضافه می‌کنیم تا نیاز به ری‌استارت برنامه نباشه
  const defaultInstallDir = 'C:\\Program Files\\nodejs'
  if (!process.env.PATH.includes(defaultInstallDir)) {
    process.env.PATH = defaultInstallDir + path.delimiter + process.env.PATH
  }

  sendLog('✅ Node.js با موفقیت نصب شد.')
}

ipcMain.handle('check-node', async () => {
  if (isNodeInstalled()) return { installed: true }

  const sendLog = (line) => mainWindow.webContents.send('node-install-log', { line })
  sendLog('Node.js روی سیستم پیدا نشد. شروع نصب خودکار...')
  try {
    await installNodeAutomatically(sendLog)
    const ok = isNodeInstalled()
    return { installed: ok }
  } catch (err) {
    sendLog('❌ خطا در نصب خودکار: ' + err.message)
    sendLog('لطفاً به‌صورت دستی از nodejs.org نصب کنید.')
    return { installed: false, error: err.message }
  }
})

// ===== آماده‌سازی دستی سیستم: Node.js + Python + Build Tools، همین الان (بدون نیاز به ساخت بات) =====
ipcMain.handle('ensure-system-ready', async () => {
  const sendLog = (line) => mainWindow.webContents.send('node-install-log', { line })
  try {
    if (!isNodeInstalled()) {
      sendLog('Node.js پیدا نشد. شروع نصب...')
      await installNodeAutomatically(sendLog)
    } else {
      sendLog('✅ Node.js از قبل نصبه.')
    }

    if (isPythonInstalled() && isBuildToolsInstalled()) {
      sendLog('✅ Python و Build Tools هم از قبل نصبن — سیستم آماده‌ست.')
    } else {
      await ensureNativeBuildTools(sendLog)
    }

    sendLog('🎉 سیستم کاملاً آماده‌ست.')
    return { ok: true }
  } catch (err) {
    sendLog('❌ خطا: ' + err.message)
    return { ok: false, error: err.message }
  }
})

// ===== چک و نصب خودکار Python و Visual Studio Build Tools (برای پکیج‌های native مثل canvas) =====
// این‌ها فقط برای بات‌های «پیشرفته/سروایول» لازمن (چون از prismarine-viewer استفاده می‌کنن)
function isPythonInstalled() {
  for (const cmd of ['python', 'py']) {
    try {
      const result = spawnSync(cmd, ['--version'], { shell: true })
      if (result.status === 0) return true
    } catch {}
  }
  return false
}

function isBuildToolsInstalled() {
  try {
    const vswherePath = 'C:\\Program Files (x86)\\Microsoft Visual Studio\\Installer\\vswhere.exe'
    if (!fs.existsSync(vswherePath)) return false
    const result = spawnSync(vswherePath, [
      '-products', '*',
      '-requires', 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64',
      '-property', 'installationPath'
    ], { shell: true })
    return result.status === 0 && result.stdout && result.stdout.toString().trim().length > 0
  } catch {
    return false
  }
}

async function installPythonAutomatically(sendLog) {
  const version = '3.13.15'
  const fileName = `python-${version}-amd64.exe`
  const url = `https://www.python.org/ftp/python/${version}/${fileName}`
  const destPath = path.join(os.tmpdir(), fileName)

  sendLog(`در حال دانلود Python ${version}...`)
  await downloadFile(url, destPath, (percent) => sendLog(`دانلود Python: ${percent}%`, true))

  sendLog('در حال نصب Python (ممکنه چند دقیقه طول بکشه)...')
  await new Promise((resolve, reject) => {
    const install = spawn(destPath, ['/quiet', 'InstallAllUsers=1', 'PrependPath=1', 'Include_test=0'], { shell: true })
    install.on('close', (code) => (code === 0 ? resolve() : reject(new Error('کد خروجی نصب Python: ' + code))))
    install.on('error', reject)
  })

  const defaultDir = 'C:\\Program Files\\Python313'
  if (!process.env.PATH.includes(defaultDir)) {
    process.env.PATH = defaultDir + path.delimiter + defaultDir + '\\Scripts' + path.delimiter + process.env.PATH
  }
  sendLog('✅ Python نصب شد.')
}

async function installBuildToolsAutomatically(sendLog) {
  const url = 'https://aka.ms/vs/17/release/vs_buildtools.exe'
  const destPath = path.join(os.tmpdir(), 'vs_buildtools.exe')

  sendLog('در حال دانلود Visual Studio Build Tools...')
  await downloadFile(url, destPath, (percent) => sendLog(`دانلود Build Tools: ${percent}%`, true))

  sendLog('در حال نصب Build Tools — این می‌تونه ۵ تا ۱۵ دقیقه طول بکشه، لطفاً صبر کنید...')
  await new Promise((resolve, reject) => {
    const install = spawn(destPath, [
      '--quiet', '--wait', '--norestart', '--nocache',
      '--add', 'Microsoft.VisualStudio.Workload.VCTools',
      '--includeRecommended'
    ], { shell: true })
    install.on('close', (code) => {
      // کدهای خروجی 0 یا 3010 (نیاز به ری‌استارت) هر دو یعنی نصب موفق بوده
      if (code === 0 || code === 3010) resolve()
      else reject(new Error('کد خروجی نصب Build Tools: ' + code))
    })
    install.on('error', reject)
  })
  sendLog('✅ Build Tools نصب شد.')
}

async function ensureNativeBuildTools(sendLog) {
  if (isPythonInstalled() && isBuildToolsInstalled()) {
    sendLog('پیش‌نیازهای کامپایل (Python و Build Tools) از قبل نصب هستن.')
    return
  }
  sendLog('⚠️ برای بات‌های پیشرفته/سروایول، پکیج‌هایی مثل canvas نیاز به کامپایل دارن. در حال آماده‌سازی خودکار پیش‌نیازها...')
  if (!isPythonInstalled()) {
    await installPythonAutomatically(sendLog)
  }
  if (!isBuildToolsInstalled()) {
    await installBuildToolsAutomatically(sendLog)
  }
}

function jsStringLiteral(value) {
  return JSON.stringify(String(value))
}
function jsBoolLiteral(value) {
  return value ? 'true' : 'false'
}

// اسم پکیج‌هایی که برای اجرای درست بات لازمن، مستقیم از package.json تمپلیت خونده می‌شه
// تا اگه بعداً پکیج جدیدی اضافه شد، همین‌جا هم خودکار به‌روز بشه.
function getRequiredDeps(botType) {
  const pkgTemplateName = botType === 'free' ? 'free-package-template.json' : 'bot-package-template.json'
  const pkgTemplate = fs.readFileSync(path.join(__dirname, pkgTemplateName), 'utf-8')
  const pkg = JSON.parse(pkgTemplate.replace('{{NAME}}', 'x'))
  return Object.keys(pkg.dependencies || {})
}

// بات‌هایی که واقعاً از prismarine-viewer (و در نتیجه از پکیج native مثل canvas) استفاده می‌کنن
function needsLiveViewer(botType) {
  return botType === 'viewer' || botType === 'survival' || botType === 'bedwars'
}

// بررسی می‌کنه پکیج native کنواس واقعاً کار می‌کنه یا نه — به‌جای حدس زدن مسیر فایل باینری
// (که بسته به نسخه‌ی canvas و ویندوز فرق می‌کنه)، مستقیم امتحان می‌کنیم که require بشه یا نه.
// این دقیق‌ترین راهه چون همون کاریه که واقعاً موقع اجرای بات هم اتفاق می‌افته.
function canvasBinaryBuilt(folder) {
  try {
    const result = spawnSync('node', ['-e', "require('canvas'); process.exit(0)"], { cwd: folder, shell: true, timeout: 15000 })
    return result.status === 0
  } catch {
    return false
  }
}

// موقع شکست، خطای واقعی require('canvas') رو برمی‌گردونه تا معلوم بشه دقیقاً چی خرابه
// (مثلاً DLL جاافتاده، نسخه‌ی Node ناسازگار، یا خودِ کامپایل ناقص)
function canvasRequireErrorDetail(folder) {
  try {
    const result = spawnSync('node', ['-e', "require('canvas')"], { cwd: folder, shell: true, timeout: 15000 })
    return (result.stderr ? result.stderr.toString() : '').trim().split('\n').slice(-3).join(' | ')
  } catch (e) {
    return e.message
  }
}

// بررسی می‌کنه همه‌ی پکیج‌های لازم واقعاً توی node_modules هستن یا نه — و برای بات‌های نمایش‌زنده،
// اینکه پکیج native کنواس هم واقعاً به‌درستی ساخته شده، نه فقط پوشه‌ش وجود داره
function verifyModules(folder, botType) {
  const deps = getRequiredDeps(botType)
  const depsOk = deps.every((dep) => {
    try { return fs.existsSync(path.join(folder, 'node_modules', dep, 'package.json')) } catch { return false }
  })
  if (!depsOk) return false
  if (needsLiveViewer(botType) && !canvasBinaryBuilt(folder)) return false
  return true
}

function nextViewerPort(list) {
  const used = list.map((b) => b.viewerPort).filter(Boolean)
  return used.length ? Math.max(...used) + 1 : 3300
}

function buildBotCode(entry) {
  if (entry.botType === 'free') {
    const template = fs.readFileSync(path.join(__dirname, 'free-bot-template.js'), 'utf-8')
    return template
      .replace('{{HOST}}', jsStringLiteral(entry.host))
      .replace('{{PORT}}', Number(entry.port) || 25565)
      .replace('{{USERNAME}}', jsStringLiteral(entry.username))
      .replace('{{VERSION}}', jsStringLiteral(entry.version))
      .replace('{{LOGIN_PASSWORD}}', jsStringLiteral(entry.password || ''))
  }

  const template = fs.readFileSync(path.join(__dirname, 'bot-template.js'), 'utf-8')
  const isViewer = entry.botType === 'viewer'
  const isSurvival = entry.botType === 'survival'
  const isBedwars = entry.botType === 'bedwars'
  const isVoicechat = entry.botType === 'voicechat'
  return template
    .replace('{{HOST}}', jsStringLiteral(entry.host))
    .replace('{{PORT}}', Number(entry.port) || 25565)
    .replace('{{USERNAME}}', jsStringLiteral(entry.username))
    .replace('{{VERSION}}', jsStringLiteral(entry.version))
    .replace('{{LOGIN_PASSWORD}}', jsStringLiteral(entry.password || ''))
    .replace('{{CHAT_PASSTHROUGH}}', jsBoolLiteral(isViewer || isBedwars || isVoicechat))
    .replace('{{GOTO_LOBBY_ON_DEATH}}', jsBoolLiteral(isViewer))
    .replace('{{LIVE_VIEWER}}', jsBoolLiteral(isViewer || isSurvival || isBedwars))
    .replace('{{VIEWER_PORT}}', Number(entry.viewerPort) || 3300)
    .replace('{{SURVIVAL_MODE}}', jsBoolLiteral(isSurvival))
    .replace('{{BEDWARS_MODE}}', jsBoolLiteral(isBedwars))
    .replace('{{VOICECHAT_MODE}}', jsBoolLiteral(isVoicechat))
    .replace('{{PLAYLIST_JSON}}', JSON.stringify(Array.isArray(entry.playlist) ? entry.playlist : []))
    .replace('{{DEFAULT_SONG}}', jsStringLiteral(entry.defaultSong || ''))
    .replace('{{TRACK_DURATION_MS}}', Number(entry.trackDurationMs) || 180000)
    .replace('{{JOIN_COMMAND}}', jsStringLiteral(entry.joinCommand || ''))
}

// نصب یا کپی پکیج‌ها با تایید واقعی موفقیت (نه فقط فرض کردن که کار کرده)
async function installDependencies(folder, list, sendProgress, botType) {
  const sameTypeList = list.filter((b) => (b.botType === 'free') === (botType === 'free'))
  const existingWithModules = sameTypeList.find((b) => {
    try { return verifyModules(b.folder, botType) } catch { return false }
  })

  // خروجی واقعی npm رو نگه می‌داریم تا اگه نصب شکست خورد، دلیل واقعیش (نه فقط "نصب نشد") نشون داده بشه
  let lastErrorOutput = ''
  const runNpmInstall = (extraLabel, extraArgs) => new Promise((resolve) => {
    let percent = 20
    let stderrBuf = ''
    let stdoutBuf = ''
    sendProgress(percent, extraLabel || 'در حال دانلود و نصب پکیج‌ها (اولین بار کمی طول می‌کشه)...')
    const timer = setInterval(() => {
      percent = Math.min(percent + 2, 90)
      sendProgress(percent)
    }, 700)
    const install = spawn('npm', ['install', '--no-audit', '--no-fund', ...(extraArgs || [])], { cwd: folder, shell: true })
    install.stdout.on('data', (d) => { stdoutBuf = (stdoutBuf + d.toString()).slice(-4000) })
    install.stderr.on('data', (d) => { stderrBuf = (stderrBuf + d.toString()).slice(-4000) })
    install.on('close', (code) => {
      clearInterval(timer)
      if (code !== 0) lastErrorOutput = (stderrBuf.trim() || stdoutBuf.trim()).slice(-1500)
      resolve(code)
    })
    install.on('error', (err) => { clearInterval(timer); lastErrorOutput = err.message; resolve(1) })
  })

  if (existingWithModules) {
    await new Promise((resolve) => {
      let percent = 20
      sendProgress(percent, 'کپی کردن پکیج‌های نصب‌شده از یه بات قبلی...')
      const timer = setInterval(() => {
        percent = Math.min(percent + 6, 90)
        sendProgress(percent)
      }, 120)
      fs.cp(path.join(existingWithModules.folder, 'node_modules'), path.join(folder, 'node_modules'), { recursive: true }, (err) => {
        clearInterval(timer)
        if (err) console.error('خطا در کپی node_modules:', err.message)
        resolve()
      })
    })
    if (verifyModules(folder, botType)) {
      sendProgress(95, 'تقریباً تمومه...')
      return true
    }
    // کپی کامل نبود (مثلاً بات منبع پکیج جدیدی رو نداشت) — نصب واقعی رو انجام می‌دیم
    sendProgress(20, 'کپی ناقص بود، در حال نصب مستقیم پکیج‌های جامونده...')
  }

  const code = await runNpmInstall(null, ['--prefer-offline'])
  const ok = code === 0 && verifyModules(folder, botType)
  if (!ok) {
    // یه بار دیگه بدون فلگ‌های آفلاین امتحان می‌کنیم، شاید مشکل کش بوده
    sendProgress(20, 'نصب اول موفق نبود، یه بار دیگه امتحان می‌کنیم...')
    await runNpmInstall(null, [])
  }
  const finalOk = verifyModules(folder, botType)
  if (finalOk) {
    sendProgress(95, 'تقریباً تمومه...')
  } else {
    let detail = lastErrorOutput ? (' — خطای npm: ' + lastErrorOutput.split('\n').slice(-3).join(' | ')) : ''
    if (needsLiveViewer(botType) && !canvasBinaryBuilt(folder)) {
      const canvasErr = canvasRequireErrorDetail(folder)
      if (canvasErr) detail += (detail ? '   |   ' : ' — ') + 'خطای canvas: ' + canvasErr
    }
    sendProgress(95, '❌ نصب شکست خورد' + detail)
  }
  return finalOk
}

// ===== ساخت بات جدید =====
const LIMITED_TYPES = ['mobile', 'survival'] // انواعی که بعد از ۲۰ تا نیاز به رمز دارن
const BOT_CAP_LIMIT = 20
const GATE_PASSWORD = 'moz@555'

ipcMain.handle('create-bot', async (event, data) => {
  const list = loadStore()
  const botType = data.botType === 'free' ? 'free' : (['viewer', 'survival', 'bedwars', 'voicechat'].includes(data.botType) ? data.botType : 'mobile')

  // بات ساده (رایگان) بدون هیچ محدودیت یا رمزی قابل ساخته
  // ولی بات‌های متحرک/سروایول بعد از ۲۰ تا نیاز به رمز دارن (بات پیشرفته از اول رمز داره)
  if (LIMITED_TYPES.includes(botType)) {
    const limitedCount = list.filter((b) => LIMITED_TYPES.includes(b.botType)).length
    if (limitedCount >= BOT_CAP_LIMIT && data.unlockPassword !== GATE_PASSWORD) {
      return { error: `به سقف ${BOT_CAP_LIMIT} بات رسیدید. برای ساخت بیشتر باید رمز رو وارد کنید.`, needPassword: true }
    }
  }

  const id = 'bot_' + Date.now()
  const folder = path.join(botsDir, id)
  fs.mkdirSync(folder, { recursive: true })

  const sendProgress = (percent, line) =>
    mainWindow.webContents.send('install-log', { id, percent, line: line ? line + '\n' : undefined })

  sendProgress(5, 'در حال آماده‌سازی پوشه بات...')

  const entry = {
    id, name: data.name || id, host: data.host, port: data.port,
    username: data.username, version: data.version, password: data.password || '',
    folder, autoStart: !!data.autoStart, botType,
    viewerPort: (botType !== 'mobile' && botType !== 'free' && botType !== 'voicechat') ? nextViewerPort(list) : null,
    playlist: Array.isArray(data.playlist) ? data.playlist : [],
    defaultSong: data.defaultSong || '',
    trackDurationMs: Number(data.trackDurationMs) || 180000,
    joinCommand: data.joinCommand || ''
  }

  fs.writeFileSync(path.join(folder, 'bot.js'), buildBotCode(entry))

  const pkgTemplateName = botType === 'free' ? 'free-package-template.json' : 'bot-package-template.json'
  const pkgTemplate = fs.readFileSync(path.join(__dirname, pkgTemplateName), 'utf-8')
  const pkg = pkgTemplate.replace('{{NAME}}', id)
  fs.writeFileSync(path.join(folder, 'package.json'), pkg)

  sendProgress(15, 'در حال بررسی نصب‌های قبلی برای سریع‌تر شدن کار...')

  // بات پیشرفته/سروایول از prismarine-viewer استفاده می‌کنه که نیاز به Python و Build Tools داره
  if (needsLiveViewer(botType)) {
    try {
      await ensureNativeBuildTools((line) => sendProgress(undefined, line))
    } catch (err) {
      sendProgress(undefined, '⚠️ نصب خودکار پیش‌نیازها ناموفق بود: ' + err.message)
      sendProgress(undefined, 'می‌تونید بعداً دستی نصب کنید و از «نصب مجدد پکیج‌ها» استفاده کنید.')
    }
  }

  const success = await installDependencies(folder, list, sendProgress, botType)

  list.push(entry)
  saveStore(list)

  sendProgress(100, success ? '✅ نصب کامل شد.' : '⚠️ نصب با مشکل تموم شد — از دکمه‌ی «نصب مجدد پکیج‌ها» استفاده کن.')
  return { ...entry, installOk: success }
})

// ===== نصب مجدد پکیج‌های یه بات خراب =====
ipcMain.handle('reinstall-bot', async (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }

  const sendProgress = (percent, line) =>
    mainWindow.webContents.send('install-log', { id, percent, line: line ? line + '\n' : undefined })

  if (needsLiveViewer(entry.botType)) {
    try {
      await ensureNativeBuildTools((line) => sendProgress(undefined, line))
    } catch (err) {
      sendProgress(undefined, '⚠️ نصب خودکار پیش‌نیازها ناموفق بود: ' + err.message)
    }
  }

  try { fs.rmSync(path.join(entry.folder, 'node_modules'), { recursive: true, force: true }) } catch {}
  sendProgress(10, 'در حال نصب مجدد پکیج‌ها...')
  const success = await installDependencies(entry.folder, list.filter((b) => b.id !== id), sendProgress, entry.botType)
  sendProgress(100, success ? '✅ نصب مجدد کامل شد.' : '⚠️ باز هم مشکل داشت — اتصال اینترنتت رو چک کن.')
  return { ok: success }
})

// ===== لیست بات‌ها =====
ipcMain.handle('get-bots', () => {
  const list = loadStore()
  return list.map((b) => ({ ...b, running: processes.has(b.id) }))
})

// ===== استارت =====
ipcMain.handle('start-bot', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry || processes.has(id)) return { ok: false }

  if (!verifyModules(entry.folder, entry.botType)) {
    const missingDeps = getRequiredDeps(entry.botType).filter((dep) => {
      try { return !fs.existsSync(path.join(entry.folder, 'node_modules', dep, 'package.json')) } catch { return true }
    })
    let reason = missingDeps.length > 0
      ? `پکیج‌های زیر نصب نیستن: ${missingDeps.join(', ')}`
      : 'پکیج canvas (لازم برای نمایش زنده) درست کار نمی‌کنه.'
    mainWindow.webContents.send('bot-log', { id, line: `❌ بات روشن نشد — ${reason}\n   از دکمه‌ی «نصب مجدد پکیج‌ها» استفاده کن.\n` })
    return { ok: false, reason: 'missing-modules' }
  }

  const child = spawn('node', ['bot.js'], { cwd: entry.folder, env: { ...process.env } })
  processes.set(id, child)

  child.stdout.on('data', (d) => mainWindow.webContents.send('bot-log', { id, line: d.toString() }))
  child.stderr.on('data', (d) => mainWindow.webContents.send('bot-log', { id, line: d.toString() }))
  child.on('error', (err) => {
    mainWindow.webContents.send('bot-log', { id, line: '❌ اجرا نشد: ' + err.message + '\n' })
  })
  child.on('close', (code) => {
    processes.delete(id)
    if (code && code !== 0) {
      mainWindow.webContents.send('bot-log', { id, line: `⚠️ بات با کد خروجی ${code} بسته شد.\n` })
    }
    mainWindow.webContents.send('bot-status', { id, running: false })
  })

  mainWindow.webContents.send('bot-status', { id, running: true })
  return { ok: true }
})

// ===== استاپ =====
ipcMain.handle('stop-bot', (event, id) => {
  const proc = processes.get(id)
  if (proc) proc.kill()
  processes.delete(id)
  mainWindow.webContents.send('bot-status', { id, running: false })
  return { ok: true }
})

// ===== ارسال دستور به بات (مثل "چوب جمع کن") =====
ipcMain.handle('send-command', (event, { id, text }) => {
  const proc = processes.get(id)
  if (proc) proc.stdin.write(text + '\n')
  return { ok: true }
})

// ===== حذف بات =====
ipcMain.handle('delete-bot', (event, id) => {
  const proc = processes.get(id)
  if (proc) { proc.kill(); processes.delete(id) }

  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (entry && fs.existsSync(entry.folder)) {
    fs.rmSync(entry.folder, { recursive: true, force: true })
  }
  saveStore(list.filter((b) => b.id !== id))
  return { ok: true }
})

// ===== خوندن/ذخیره کد بات برای ویرایش داخل برنامه =====
ipcMain.handle('get-bot-code', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return ''
  return fs.readFileSync(path.join(entry.folder, 'bot.js'), 'utf-8')
})

ipcMain.handle('save-bot-code', (event, { id, code }) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }
  fs.writeFileSync(path.join(entry.folder, 'bot.js'), code)
  return { ok: true }
})

// ===== باز کردن پوشه بات (اختیاری) =====
ipcMain.handle('open-bot-folder', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (entry) shell.openPath(entry.folder)
  return { ok: true }
})

// ===== خوندن وضعیت زنده بات (جون، غذا، موقعیت، کار فعلی) =====
ipcMain.handle('get-bot-status', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return null
  const statusPath = path.join(entry.folder, 'status.json')
  if (!fs.existsSync(statusPath)) return null
  try {
    return JSON.parse(fs.readFileSync(statusPath, 'utf-8'))
  } catch {
    return null
  }
})

// ===== خوندن/ذخیره تنظیمات بات (آی‌پی، پورت، یوزرنیم، نسخه، رمز، کلیدهای API) =====
ipcMain.handle('get-bot-settings', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  return entry || null
})

ipcMain.handle('save-bot-settings', (event, { id, data }) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }

  entry.name = data.name || entry.name
  entry.host = data.host
  entry.port = data.port
  entry.username = data.username
  entry.version = data.version
  entry.password = data.password || ''
  saveStore(list)

  // بازسازی فایل bot.js با تنظیمات جدید (توجه: اگه دستی کد رو ویرایش کرده باشید، این بازنویسی می‌کنه)
  fs.writeFileSync(path.join(entry.folder, 'bot.js'), buildBotCode(entry))

  return { ok: true }
})

// ===== به‌روزرسانی لیست‌پخش/آهنگ پیش‌فرض/دستور ورود یه بات ویس‌چت (بدون نیاز به ساخت دوباره) =====
ipcMain.handle('update-playlist', (event, { id, playlist, defaultSong, trackDurationMs, joinCommand }) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry) return { ok: false }

  entry.playlist = Array.isArray(playlist) ? playlist : entry.playlist || []
  entry.defaultSong = defaultSong !== undefined ? defaultSong : entry.defaultSong || ''
  entry.trackDurationMs = Number(trackDurationMs) || entry.trackDurationMs || 180000
  entry.joinCommand = joinCommand !== undefined ? joinCommand : entry.joinCommand || ''
  saveStore(list)

  fs.writeFileSync(path.join(entry.folder, 'bot.js'), buildBotCode(entry))
  return { ok: true }
})

// ===== باز کردن نمایشگر زنده بات توی مرورگر =====
ipcMain.handle('open-viewer', (event, id) => {
  const list = loadStore()
  const entry = list.find((b) => b.id === id)
  if (!entry || !entry.viewerPort) return { ok: false }
  shell.openExternal(`http://localhost:${entry.viewerPort}`)
  return { ok: true }
})

// ===== فرستادن وضعیت کنترل زنده (کیبورد/موس) به بات =====
ipcMain.handle('send-control', (event, { id, state }) => {
  const child = processes.get(id)
  if (!child || !child.stdin || !child.stdin.writable) return { ok: false }
  try {
    child.stdin.write('__CTRL__:' + JSON.stringify(state) + '\n')
    return { ok: true }
  } catch (e) {
    return { ok: false }
  }
})

// ===== خروجی گرفتن از تنظیمات همه‌ی بات‌ها (بدون node_modules، فقط تنظیمات) =====
ipcMain.handle('export-bots', async () => {
  const list = loadStore()
  const exportable = list.map(({ folder, ...rest }) => rest) // مسیر پوشه‌ی محلی رو صادر نمی‌کنیم، روی کامپیوتر جدید فرق می‌کنه
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'خروجی گرفتن از تنظیمات بات‌ها',
    defaultPath: 'minecraft-bots-backup.json',
    filters: [{ name: 'JSON', extensions: ['json'] }]
  })
  if (result.canceled || !result.filePath) return { ok: false }
  fs.writeFileSync(result.filePath, JSON.stringify(exportable, null, 2))
  return { ok: true, path: result.filePath }
})

// ===== وارد کردن تنظیمات بات‌ها از یه فایل خروجی‌گرفته‌شده قبلی =====
ipcMain.handle('import-bots', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'وارد کردن تنظیمات بات‌ها',
    filters: [{ name: 'JSON', extensions: ['json'] }],
    properties: ['openFile']
  })
  if (result.canceled || !result.filePaths[0]) return { ok: false }

  let imported
  try {
    imported = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf-8'))
  } catch (e) {
    return { ok: false, error: 'فایل معتبر نیست: ' + e.message }
  }
  if (!Array.isArray(imported)) return { ok: false, error: 'فرمت فایل درست نیست.' }

  const list = loadStore()
  let importedCount = 0
  for (const item of imported) {
    const id = 'bot_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7)
    const folder = path.join(botsDir, id)
    fs.mkdirSync(folder, { recursive: true })
    const entry = { ...item, id, folder }
    fs.writeFileSync(path.join(folder, 'bot.js'), buildBotCode(entry))
    const pkgTemplateName = entry.botType === 'free' ? 'free-package-template.json' : 'bot-package-template.json'
    const pkgTemplate = fs.readFileSync(path.join(__dirname, pkgTemplateName), 'utf-8')
    fs.writeFileSync(path.join(folder, 'package.json'), pkgTemplate.replace('{{NAME}}', id))

    const sendProgress = (percent, line) =>
      mainWindow.webContents.send('install-log', { id, percent, line: line ? line + '\n' : undefined })
    if (needsLiveViewer(entry.botType)) {
      try { await ensureNativeBuildTools((line) => sendProgress(undefined, line)) } catch (e) {}
    }
    await installDependencies(folder, list, sendProgress, entry.botType)

    list.push(entry)
    importedCount++
  }
  saveStore(list)
  return { ok: true, count: importedCount }
})

// ===== استارت خودکار بات‌هایی که autoStart دارن، موقع باز شدن برنامه =====
app.whenReady().then(() => {
  setTimeout(() => {
    const list = loadStore()
    for (const entry of list) {
      if (entry.autoStart) {
        if (!verifyModules(entry.folder, entry.botType)) {
          mainWindow.webContents.send('bot-log', { id: entry.id, line: '❌ پکیج‌های این بات کامل نصب نشدن، اجرا نشد.\n' })
          continue
        }
        const child = spawn('node', ['bot.js'], { cwd: entry.folder, env: { ...process.env } })
        processes.set(entry.id, child)
        child.stdout.on('data', (d) => mainWindow.webContents.send('bot-log', { id: entry.id, line: d.toString() }))
        child.stderr.on('data', (d) => mainWindow.webContents.send('bot-log', { id: entry.id, line: d.toString() }))
        child.on('error', (err) => mainWindow.webContents.send('bot-log', { id: entry.id, line: '❌ اجرا نشد: ' + err.message + '\n' }))
        child.on('close', (code) => {
          processes.delete(entry.id)
          if (code && code !== 0) mainWindow.webContents.send('bot-log', { id: entry.id, line: `⚠️ بات با کد خروجی ${code} بسته شد.\n` })
          mainWindow.webContents.send('bot-status', { id: entry.id, running: false })
        })
      }
    }
  }, 1000)
})
