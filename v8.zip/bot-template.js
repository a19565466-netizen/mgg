// bot.js — به‌صورت خودکار توسط برنامه ساخته شده
// نسخه‌ی بدون هوش مصنوعی: هیچ API خارجی صدا زده نمی‌شه، همه‌چیز قانون‌محور (rule-based) و رایگانه.

// ===== جلوگیری از کرش خام: این‌ها باید قبل از هر require دیگه‌ای ثبت بشن =====
// اگه پکیج‌ها ناقص نصب شده باشن، require زیر پرتاب خطا می‌کنه؛ این try/catch
// به‌جای یه استک‌تریس خام، یه پیام فارسی روشن نشون می‌ده و پروسه رو تمیز می‌بنده.
process.on('uncaughtException', (err) => {
  console.log('❌ خطای مدیریت‌نشده:', err && err.message)
})
process.on('unhandledRejection', (err) => {
  console.log('❌ خطای Promise مدیریت‌نشده:', err && err.message)
})

let mineflayer, pathfinder, Movements, goals, collectBlockPlugin, autoEatPlugin
try {
  mineflayer = require('mineflayer')
  ;({ pathfinder, Movements, goals } = require('mineflayer-pathfinder'))
  collectBlockPlugin = require('mineflayer-collectblock').plugin
  ;({ plugin: autoEatPlugin } = require('mineflayer-auto-eat'))
} catch (err) {
  console.log('❌ پکیج‌های موردنیاز کامل نصب نشدن (' + err.message + ').')
  console.log('این بات رو حذف کن و دوباره بساز، یا از دکمه‌ی «نصب مجدد پکیج‌ها» استفاده کن.')
  process.exit(1)
}
const readline = require('readline')
const fs = require('fs')
const path = require('path')
const https = require('https')
const http = require('http')

const BOT_DIR = __dirname
const MEMORY_FILE = path.join(BOT_DIR, 'memory.json')
const STATUS_FILE = path.join(BOT_DIR, 'status.json')

// ===== تنظیمات (توسط برنامه پر می‌شه) =====
const LOGIN_PASSWORD = {{LOGIN_PASSWORD}}
const HOST = {{HOST}}
const PORT = {{PORT}}
const USERNAME = {{USERNAME}}
const VERSION = {{VERSION}}
// وقتی true باشه: هرچی توی کنسول تایپ کنی عیناً توی چت بازی گفته می‌شه (به‌جای تفسیر به‌عنوان دستور)
const CHAT_PASSTHROUGH = {{CHAT_PASSTHROUGH}}
// وقتی true باشه: بعد از مرگ، خودکار توی چت "/lobby" می‌فرسته
const GOTO_LOBBY_ON_DEATH = {{GOTO_LOBBY_ON_DEATH}}
// وقتی true باشه: یه نمایشگر زنده (توی مرورگر) از دید بات راه‌اندازی می‌شه
const LIVE_VIEWER = {{LIVE_VIEWER}}
const VIEWER_PORT = {{VIEWER_PORT}}
// وقتی true باشه: بات خودش وارد سروایول می‌شه، رندوم تلپورت می‌شه، خودکار چوب جمع می‌کنه
// و اگه بهش حمله بشه از خودش دفاع می‌کنه — بدون کنترل دستی، فقط با نمایشگر زنده قابل تماشاست
const SURVIVAL_MODE = {{SURVIVAL_MODE}}
// وقتی true باشه: بات موقع ورود «/Bedwars» می‌زنه و سعی می‌کنه با NPC لابی تعامل کنه و وارد بازی بشه.
// این بخش کاملاً حدسی/آزمایشیه چون منوی هر سرور فرق داره — ممکنه نیاز به تنظیم دستی داشته باشه.
const BEDWARS_MODE = {{BEDWARS_MODE}}
// وقتی true باشه: بات با یه لیست‌پخش (یا آهنگ پیش‌فرض) وارد سرور می‌شه و از طریق دستور
// «/simple_voice_radio» سعی می‌کنه توی ویس‌چت پخش کنه (فرض بر اینه این پلاگین رو سرور نصب داره)
const VOICECHAT_MODE = {{VOICECHAT_MODE}}
const PLAYLIST = {{PLAYLIST_JSON}}
const DEFAULT_SONG = {{DEFAULT_SONG}}
const TRACK_DURATION_MS = {{TRACK_DURATION_MS}}
// دستوری که وقتی وارد سرور می‌شه بزنه (مثلاً برای ورود به یه حالت/نقش خاص روی سرور)
const JOIN_COMMAND = {{JOIN_COMMAND}}
// لینک فایل‌های مودی که فقط دانلود می‌شن (ذخیره‌ی فایل — نصب/بارگذاری واقعی مود ممکن نیست، چون بات یه کلاینت جاوا نیست)
const MOD_URLS = {{MOD_URLS_JSON}}

let reconnectAttempts = 0
const MAX_RECONNECT_DELAY_MS = 60000


// ===== تشخیص زبان متن (فقط برای انتخاب زبان پاسخ، بدون نیاز به API) =====
function isPersianText(text) {
  return /[\u0600-\u06FF]/.test(text)
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

// چند جمله‌ی آماده برای موقع جنگیدن، تا بات موقع «بجنگ» یه‌کم حس بازی واقعی بده
const BATTLE_CRIES = [
  'بجنگ بجنگ! 😤', 'بگیر که اومدم!', 'فرار نکن!', 'الان حالتو می‌گیرم!', 'آماده باش!'
]

// نگاشت اسم فارسی بلوک‌ها به کلمه کلیدی داخل اسم انگلیسی بلوک
const BLOCK_KEYWORDS = {
  'چوب': 'log', 'هیزم': 'log', 'سنگ': 'stone', 'خاک': 'dirt', 'شن': 'sand',
  'شنریزه': 'gravel', 'سنگریزه': 'gravel', 'چمن': 'grass_block', 'زغال': 'coal_ore',
  'آهن': 'iron_ore', 'طلا': 'gold_ore', 'الماس': 'diamond_ore', 'برگ': 'leaves',
  'کوارتز': 'quartz', 'ردستون': 'redstone_ore', 'لاپیس': 'lapis_ore'
}

// نگاشت اسم فارسی موجودات به اسم انگلیسی برای حمله
const MOB_KEYWORDS = {
  'گوسفند': 'sheep', 'گاو': 'cow', 'خوک': 'pig', 'مرغ': 'chicken', 'جوجه': 'chicken',
  'زامبی': 'zombie', 'اسکلت': 'skeleton', 'کریپر': 'creeper', 'عنکبوت': 'spider',
  'اندرمن': 'enderman', 'خفاش': 'bat', 'اسب': 'horse'
}

// ===== حافظه‌ی بلندمدت مکالمه (بین ری‌استارت‌ها هم می‌مونه) =====
let conversationHistory = {}
try {
  if (fs.existsSync(MEMORY_FILE)) {
    conversationHistory = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'))
  }
} catch (e) {
  console.log('نتونستم حافظه‌ی قبلی رو بخونم، از صفر شروع می‌کنم.')
}
function saveMemory() {
  try { fs.writeFileSync(MEMORY_FILE, JSON.stringify(conversationHistory)) } catch (e) {}
}

let bot
let isBusy = false
let currentAction = 'بیکار'
let survivalLoopStarted = false
let survivalModeActive = SURVIVAL_MODE // برای انواع غیر سروایول، با دستور «شروع سروایول» می‌شه فعالش کرد
let bedwarsSequenceStarted = false
let bedwarsConfirmed = false
let voiceChatLoopStarted = false
let musicActive = VOICECHAT_MODE
let manualControlActive = false
let manualControlTimeout = null

// ===== اعمال کنترل زنده‌ی کیبورد/موس که از برنامه می‌رسه =====
function applyControlState(state) {
  if (!bot || !bot.entity) return
  manualControlActive = true
  if (manualControlTimeout) clearTimeout(manualControlTimeout)
  manualControlTimeout = setTimeout(() => { manualControlActive = false }, 3000)
  try {
    bot.pathfinder.setGoal(null) // نذاریم مسیریابی خودکار با کنترل دستی بجنگه
    bot.setControlState('forward', !!state.forward)
    bot.setControlState('back', !!state.back)
    bot.setControlState('left', !!state.left)
    bot.setControlState('right', !!state.right)
    bot.setControlState('jump', !!state.jump)
    bot.setControlState('sprint', !!state.sprint)
    if (typeof state.yaw === 'number' && typeof state.pitch === 'number') {
      bot.look(state.yaw, state.pitch, true)
    }
  } catch (e) {}
}
let inCombat = false
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)) }

function createBot() {
  bot = mineflayer.createBot({ host: HOST, port: PORT, username: USERNAME, version: VERSION })
  bot.loadPlugin(pathfinder)
  bot.loadPlugin(collectBlockPlugin)
  bot.loadPlugin(autoEatPlugin)

  bot.on('spawn', () => {
    console.log('بات وارد بازی شد!')
    reconnectAttempts = 0
    try {
      bot.pathfinder.setMovements(new Movements(bot))
    } catch (e) {
      console.log('⚠️ راه‌اندازی مسیریابی با خطا مواجه شد:', e.message)
    }

    // ===== غذا خوردن خودکار وقتی گرسنه می‌شه =====
    try {
      bot.autoEat.options = { priority: 'foodPoints', startAt: 16, bannedFood: [] }
    } catch (e) {
      console.log('⚠️ راه‌اندازی غذاخوردن خودکار با خطا مواجه شد:', e.message)
    }

    setTimeout(() => bot.chat(`/register ${LOGIN_PASSWORD} ${LOGIN_PASSWORD}`), 1000)
    setTimeout(() => bot.chat(`/login ${LOGIN_PASSWORD}`), 2500)

    if (LIVE_VIEWER) {
      try {
        require('prismarine-viewer').mineflayer(bot, { port: VIEWER_PORT, firstPerson: true })
        console.log(`🖥 نمایش زنده در دسترسه: http://localhost:${VIEWER_PORT}`)
      } catch (e) {
        console.log('❌ نمایشگر زنده راه‌اندازی نشد — پکیج native (canvas) درست نصب نشده.')
        console.log('   از دکمه‌ی «نصب مجدد پکیج‌ها» توی پنل این بات استفاده کن.')
        console.log('   (جزئیات فنی خطا: ' + e.message + ')')
      }
    }

    if (SURVIVAL_MODE && !survivalLoopStarted) {
      survivalLoopStarted = true
      runSurvivalSequence()
    }

    if (BEDWARS_MODE && !bedwarsSequenceStarted) {
      bedwarsSequenceStarted = true
      runBedwarsSequence()
    }

    if (JOIN_COMMAND) {
      setTimeout(() => { try { bot.chat(JOIN_COMMAND) } catch (e) {} }, 3000)
    }

    if (VOICECHAT_MODE && !voiceChatLoopStarted) {
      voiceChatLoopStarted = true
      runVoiceChatSequence()
    }

    startStatusReporting()
  })

  bot.on('whisper', async (username, message) => {
    if (username === bot.username) return
    const userMessage = message.trim()
    if (!userMessage) return
    try {
      const reply = getChatReply(username, userMessage)
      sendLongWhisper(username, reply)
    } catch (err) {
      console.error('خطا در تولید پاسخ:', err.message)
      bot.whisper(username, 'ببخشید، الان نمی‌تونم جواب بدم :(')
    }
  })

  bot.on('health', () => {
    if (bot.health <= 6) console.log(`⚠️ جون بات کمه: ${bot.health}/20`)
  })

  bot.on('death', () => {
    console.log('بات مرد.')
    if (GOTO_LOBBY_ON_DEATH) {
      setTimeout(() => { try { bot.chat('/lobby') } catch (e) {} }, 1000)
    }
    if (SURVIVAL_MODE) {
      // بعد از مرگ، سرور معمولاً خودکار ریسپان می‌کنه؛ یه‌کم صبر می‌کنیم و کار رو ادامه می‌دیم
      setTimeout(() => { try { bot.respawn && bot.respawn() } catch (e) {} }, 1500)
    }
  })

  // ===== دفاع از خود: اگه بهش حمله بشه (چه بازیکن چه زامبی/موجود خصمانه)، طرف رو پیدا و شکست می‌ده =====
  bot.on('entityHurt', async (entity) => {
    if (!survivalModeActive || !bot.entity || inCombat) return
    if (!entity || entity.id !== bot.entity.id) return

    const HOSTILE_MOBS = ['zombie', 'skeleton', 'spider', 'creeper', 'enderman', 'witch', 'drowned', 'husk', 'phantom']
    // نکته: نیازی به «چرخیدن» بات نیست — تشخیص موجودیت‌ها توی مای‌ن‌فلایر بر اساس داده‌ی بازیه نه دید بصری،
    // پس بات بدون توجه به جهتی که نگاه می‌کنه، هر موجودی نزدیک رو (جلو، پشت، هرجا) پیدا می‌کنه.
    const attacker = bot.nearestEntity((e) =>
      e !== bot.entity &&
      (e.type === 'player' || (e.type === 'mob' && HOSTILE_MOBS.includes(e.name))) &&
      bot.entity.position.distanceTo(e.position) < 10
    )
    if (!attacker) return

    inCombat = true
    setAction('دفاع از خود در برابر ' + (attacker.username || attacker.name || 'حمله‌کننده'))
    try { bot.chat(pick(BATTLE_CRIES)) } catch (e) {}
    try {
      await equipBestWeapon()
      const startTime = Date.now()
      const maxDurationMs = 30000
      const loseSightGraceMs = 8000
      let target = attacker
      let lastSeenAt = Date.now()

      while (Date.now() - startTime < maxDurationMs) {
        const fresh = bot.entities[target.id]
        if (fresh) {
          target = fresh
          lastSeenAt = Date.now()
          const dist = bot.entity.position.distanceTo(target.position)
          if (dist > 3) {
            try { await bot.pathfinder.goto(new goals.GoalNear(target.position.x, target.position.y, target.position.z, 2)) } catch (e) {}
          } else {
            // فاصله‌ی ۶۵۰ میلی‌ثانیه تقریباً هم‌زمان با کول‌داون حمله‌ی شمشیر توی ماینکرافته؛
            // زدن سریع‌تر از این باعث آسیب کمتر می‌شه (مکانیک بازی)، نه بیشتر.
            bot.attack(target)
            await sleep(650)
          }
        } else {
          if (Date.now() - lastSeenAt > loseSightGraceMs) break
          await sleep(400)
        }
        if (bot.health <= 0) break
      }
    } catch (e) {
      console.log('خطا توی دفاع از خود:', e.message)
    }
    inCombat = false
    setAction('سروایول خودکار')
  })

  // ===== مدیریت منوهای بدوارز (حدسی): وقتی یه منو باز می‌شه، گزینه‌ها رو یکی‌یکی امتحان می‌کنه =====
  bot.on('windowOpen', async (window) => {
    if (!BEDWARS_MODE || bedwarsConfirmed) return
    try {
      const items = (window.slots || []).filter(Boolean)
      if (items.length === 0) return
      console.log(`📋 یه منو با ${items.length} گزینه باز شد؛ در حال امتحان گزینه‌ها برای رسیدن به Bedwars...`)
      for (const it of items) {
        if (bedwarsConfirmed) break
        try {
          await bot.clickWindow(it.slot, 0, 0)
          console.log(`روی اسلات ${it.slot} (${it.name || 'نامشخص'}) کلیک شد.`)
        } catch (e) {}
        await sleep(2500)
      }
      if (!bedwarsConfirmed) {
        console.log('⚠️ هیچ‌کدوم از گزینه‌های این منو به‌طور مطمئن به Bedwars نرفت. اگه بات پیشرفته/کنترل دستی داری، از همون‌جا ادامه بده.')
      }
    } catch (e) {
      console.log('خطا توی مدیریت منو:', e.message)
    }
  })

  // ===== تشخیص ورود به Bedwars از روی پیام‌های چت سرور =====
  bot.on('message', (jsonMsg) => {
    if (!BEDWARS_MODE || bedwarsConfirmed) return
    try {
      const text = jsonMsg.toString().toLowerCase()
      if (text.includes('bedwars') || text.includes('bed wars') || text.includes('بدوارز')) {
        bedwarsConfirmed = true
        console.log('✅ به‌نظر وارد Bedwars شدیم!')
        setAction('صف/بازی Bedwars')
        waitForGameStartThenPlay()
      }
    } catch (e) {}
  })

  bot.on('error', (err) => console.log('خطا:', err.message))
  // بعضی سرورها برای اجازه‌ی ورود کامل، قبولی ریسورس‌پک رو لازم دارن — چون بات گرافیک نداره،
  // فقط خودکار قبول می‌کنه (بدون اینکه واقعاً دانلود/رندرش کنه) تا سرور بات رو مسدود نکنه
  bot.on('resourcePack', (url, hash) => {
    try { bot.acceptResourcePack() } catch (e) {}
  })

  bot.on('kicked', (reason) => console.log('اخراج شد:', reason))


  bot.on('end', () => {
    reconnectAttempts++
    const delay = Math.min(10000 * reconnectAttempts, MAX_RECONNECT_DELAY_MS)
    console.log(`اتصال قطع شد. تلاش مجدد تا ${delay / 1000} ثانیه دیگه...`)
    setTimeout(createBot, delay)
  })
}

createBot()

// ===== دانلود فایل‌های مود (فقط ذخیره‌سازی — نصب/اجرای واقعی مود امکان‌پذیر نیست) =====
if (MOD_URLS && MOD_URLS.length > 0) {
  downloadMods(MOD_URLS)
}

function downloadMods(urls) {
  const modsDir = path.join(BOT_DIR, 'mods')
  try { fs.mkdirSync(modsDir, { recursive: true }) } catch (e) {}

  urls.forEach((url) => {
    try {
      const urlObj = new URL(url)
      const fileName = path.basename(urlObj.pathname) || ('mod_' + Date.now() + '.jar')
      const destPath = path.join(modsDir, fileName)
      const client = urlObj.protocol === 'http:' ? http : https

      console.log(`📦 در حال دانلود ${fileName}...`)
      const file = fs.createWriteStream(destPath)
      client.get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          // ریدایرکت ساده رو دنبال کن
          const redirectClient = res.headers.location.startsWith('http:') ? http : https
          redirectClient.get(res.headers.location, (res2) => {
            res2.pipe(file)
            file.on('finish', () => { file.close(); console.log(`✅ ${fileName} دانلود شد (توی پوشه‌ی mods).`) })
          }).on('error', (e) => console.log(`❌ دانلود ${fileName} شکست خورد:`, e.message))
          return
        }
        if (res.statusCode !== 200) {
          console.log(`❌ دانلود ${fileName} شکست خورد: کد ${res.statusCode}`)
          file.close()
          return
        }
        res.pipe(file)
        file.on('finish', () => { file.close(); console.log(`✅ ${fileName} دانلود شد (توی پوشه‌ی mods).`) })
      }).on('error', (e) => console.log(`❌ دانلود ${fileName} شکست خورد:`, e.message))
    } catch (e) {
      console.log('❌ لینک مود نامعتبره:', url, e.message)
    }
  })
  console.log('⚠️ یادآوری: این فقط فایل مود رو دانلود می‌کنه؛ چون بات یه کلاینت جاوا نیست، نمی‌تونه واقعاً مود رو بارگذاری/اجرا کنه.')
}

// ===== پخش لیست‌پخش توی ویس‌چت (با فرض نصب بودن پلاگین Simple Voice Radio روی سرور) =====
async function runVoiceChatSequence() {
  try {
    await sleep(4000) // بعد از JOIN_COMMAND (اگه تنظیم شده) صبر می‌کنه
    const songs = (PLAYLIST && PLAYLIST.length) ? PLAYLIST : (DEFAULT_SONG ? [DEFAULT_SONG] : [])
    if (songs.length === 0) {
      console.log('هیچ آهنگی (نه لیست‌پخش، نه آهنگ پیش‌فرض) تنظیم نشده.')
      return
    }
    await playPlaylistLoop(songs)
  } catch (e) {
    console.log('خطا در شروع پخش ویس‌چت:', e.message)
  }
}

async function playPlaylistLoop(songs) {
  let i = 0
  while (musicActive && bot) {
    const song = songs[i % songs.length]
    console.log(`🎵 در حال پخش: ${song}`)
    setAction('پخش: ' + song)
    try {
      bot.chat('/simple_voice_radio stop')
      await sleep(500)
      const isUrl = /^https?:\/\//i.test(song)
      bot.chat(isUrl ? `/simple_voice_radio url ${song}` : `/simple_voice_radio file ${song}`)
    } catch (e) {
      console.log('خطا در فرستادن دستور پخش:', e.message)
    }
    i++
    // نکته: چون از چت نمی‌شه فهمید آهنگ واقعاً کِی تموم می‌شه، یه مدت‌زمان ثابت صبر می‌کنیم
    await sleep(TRACK_DURATION_MS)
  }
}

// ===== دنباله‌ی ورود به Bedwars (آزمایشی/حدسی — به منوی سرور بستگی داره) =====
async function runBedwarsSequence() {
  try {
    await sleep(2000)
    bot.chat('/Bedwars')
    setAction('در حال ورود به Bedwars')
    console.log('«/Bedwars» فرستاده شد؛ منتظر لابی...')
    await sleep(3000)
    await tryFindAndClickNpc()
  } catch (e) {
    console.log('خطا در شروع دنباله‌ی Bedwars:', e.message)
  }
}

async function tryFindAndClickNpc() {
  // نکته‌ی مهم: خیلی از سرورها NPC لابی رو با یه موجودیت نوع «player» فیک (یا آرمور استند) می‌سازن.
  // چون فرمت هر سرور فرق داره، این فقط نزدیک‌ترین موجودیت شبیه‌بازیکن رو امتحان می‌کنه.
  const npc = bot.nearestEntity((e) => e !== bot.entity && (e.type === 'player' || e.type === 'mob') && bot.entity.position.distanceTo(e.position) < 12)
  if (!npc) {
    console.log('⚠️ هیچ NPC ای نزدیک پیدا نکردم. اگه لازمه، با کنترل دستی (دستورهای حرکتی) بات رو نزدیک NPC ببر.')
    return
  }
  try {
    await bot.pathfinder.goto(new goals.GoalNear(npc.position.x, npc.position.y, npc.position.z, 2))
    bot.activateEntity(npc)
    console.log('روی نزدیک‌ترین NPC کلیک شد؛ منتظر باز شدن منو یا پیام تایید هستیم...')
  } catch (e) {
    console.log('نتونستم به NPC برسم یا باهاش تعامل کنم:', e.message)
  }
}

async function waitForGameStartThenPlay() {
  console.log('⏳ منتظر شروع بازی...')
  await sleep(20000) // سقف انتظار پیش‌فرض؛ چون تایمینگ صف هر سرور فرق می‌کنه
  startBedwarsPlayLoop()
}

async function startBedwarsPlayLoop() {
  setAction('در حال بازی Bedwars')
  console.log('🎮 شروع بازی خودکار (ساده‌شده: دفاع/حمله + جمع‌آوری منابع اطراف).')
  while (BEDWARS_MODE && bot) {
    if (inCombat || manualControlActive) { await sleep(500); continue }
    try {
      const enemy = bot.nearestEntity((e) => e.type === 'player' && e !== bot.entity && bot.entity.position.distanceTo(e.position) < 20)
      if (enemy) {
        await equipBestWeapon()
        try {
          if (bot.entity.position.distanceTo(enemy.position) > 3) {
            await bot.pathfinder.goto(new goals.GoalNear(enemy.position.x, enemy.position.y, enemy.position.z, 2))
          } else {
            bot.attack(enemy)
          }
        } catch (e) {}
        await sleep(650)
        continue
      }
      // منابعی (آیتم افتاده، مثل الماس/طلای روی جزیره) که نزدیکن رو جمع کنه
      const drop = bot.nearestEntity((e) => e.name === 'item' && bot.entity.position.distanceTo(e.position) < 16)
      if (drop) {
        try { await bot.pathfinder.goto(new goals.GoalNear(drop.position.x, drop.position.y, drop.position.z, 1)) } catch (e) {}
      } else {
        await wanderRandomly()
      }
    } catch (e) {
      console.log('خطا توی حلقه‌ی Bedwars:', e.message)
    }
    await sleep(1000)
  }
}

// ===== حلقه‌ی خودکار حالت سروایول (بدون کنترل دستی) =====
async function runSurvivalSequence() {
  try {
    await sleep(2000)
    bot.chat('/survival')
    await sleep(2500)
    bot.chat('/rtp')
    await sleep(4000)
    setAction('سروایول خودکار')
    survivalLoop()
  } catch (e) {
    console.log('خطا در شروع حالت سروایول:', e.message)
  }
}

async function survivalLoop() {
  while (survivalModeActive && bot) {
    if (inCombat || manualControlActive) { await sleep(500); continue }
    await survivalStep()
    await sleep(1000)
  }
}

// ===== کمک‌توابع بررسی اینونتوری =====
function hasItem(name) { return !!bot.inventory.items().find((i) => i.name === name) }
function countItem(name) { return bot.inventory.items().filter((i) => i.name === name).reduce((s, i) => s + i.count, 0) }
function countPlanksAndLogs() { return bot.inventory.items().filter((i) => i.name.includes('log') || i.name.includes('planks')).reduce((s, i) => s + i.count, 0) }
function nearCraftingTable() { return !!bot.findBlock({ matching: (b) => b.name === 'crafting_table', maxDistance: 8 }) }
function countCookedFood() { return bot.inventory.items().filter((i) => i.name.startsWith('cooked_')).reduce((s, i) => s + i.count, 0) }

async function gatherWood() {
  try {
    const blocks = bot.findBlocks({ matching: (b) => b.name.includes('log'), maxDistance: 48, count: 1 })
    if (blocks.length > 0) {
      const blockObj = bot.blockAt(blocks[0])
      if (blockObj) {
        try { await bot.collectBlock.collect(blockObj, { ignoreNoPath: true }) } catch (e) {}
      }
    } else {
      await wanderRandomly()
    }
  } catch (e) {}
}

async function wanderRandomly() {
  const angle = Math.random() * Math.PI * 2
  const dist = 15 + Math.random() * 15
  const t = bot.entity.position.offset(Math.cos(angle) * dist, 0, Math.sin(angle) * dist)
  try { await bot.pathfinder.goto(new goals.GoalNear(t.x, t.y, t.z, 2)) } catch (e) {}
}

// یه آیتم ساخته‌شده (مثل میز کار یا کوره) رو دست می‌گیره و جلوی پاش می‌ذاره
async function placeCraftedBlock(name) {
  const item = bot.inventory.items().find((i) => i.name === name)
  if (!item) return false
  try { await bot.equip(item, 'hand') } catch (e) { return false }
  try {
    const refBlock = bot.blockAt(bot.entity.position.offset(0, -1, 0))
    if (!refBlock) return false
    await bot.placeBlock(refBlock, { x: 0, y: 1, z: 0 })
    return true
  } catch (e) {
    return false
  }
}

// ذوب کردن آیتم توی کوره (برای سنگ آهن یا گوشت خام)
async function smeltItems(rawItemName, count) {
  let furnaceBlock = bot.findBlock({ matching: (b) => b.name === 'furnace', maxDistance: 16 })
  if (!furnaceBlock) {
    if (!hasItem('furnace')) {
      if (countItem('cobblestone') < 8) { await doCollect('stone', 8); return }
      await doCraft('furnace', 1)
      return
    }
    await placeCraftedBlock('furnace')
    return
  }
  try {
    const furnace = await bot.openFurnace(furnaceBlock)
    const fuelInInv = bot.inventory.items().find((i) => i.name.endsWith('_planks') || i.name.endsWith('_log') || i.name === 'coal')
    const rawInInv = bot.inventory.items().find((i) => i.name === rawItemName)
    if (fuelInInv) {
      try { await furnace.putFuel(fuelInInv.type, null, Math.min(fuelInInv.count, 8)) } catch (e) {}
    }
    if (rawInInv) {
      try { await furnace.putInput(rawInInv.type, null, Math.min(rawInInv.count, count)) } catch (e) {}
    }
    await sleep(11000) // هر آیتم توی کوره‌ی معمولی حدود ۱۰ ثانیه طول می‌کشه
    try {
      let out
      do { out = await furnace.takeOutput() } while (out)
    } catch (e) {}
    try { furnace.close() } catch (e) {}
  } catch (e) {
    console.log('خطا توی کوره:', e.message)
  }
}

async function huntForFood() {
  const PASSIVE_MOBS = ['cow', 'pig', 'chicken', 'sheep']
  const RAW_MEAT_ITEMS = ['beef', 'porkchop', 'chicken', 'mutton', 'rabbit']

  // اول ببینیم گوشت خام آماده‌ی پخت داریم یا نه
  const rawMeatItem = bot.inventory.items().find((i) => RAW_MEAT_ITEMS.includes(i.name))
  if (rawMeatItem) {
    await smeltItems(rawMeatItem.name, rawMeatItem.count)
    return
  }

  const animal = bot.nearestEntity((e) => PASSIVE_MOBS.includes(e.name) && bot.entity.position.distanceTo(e.position) < 32)
  if (!animal) {
    await wanderRandomly()
    return
  }
  try {
    await equipBestWeapon()
    const startTime = Date.now()
    let target = animal
    while (Date.now() - startTime < 15000) {
      const fresh = bot.entities[target.id]
      if (!fresh) break
      target = fresh
      const dist = bot.entity.position.distanceTo(target.position)
      if (dist > 3) {
        try { await bot.pathfinder.goto(new goals.GoalNear(target.position.x, target.position.y, target.position.z, 2)) } catch (e) {}
      } else {
        bot.attack(target)
        await sleep(650)
      }
    }
  } catch (e) {}
}

// ===== مرحله‌ی بعدی پیشرفت سروایول: چوب → ابزار چوبی → سنگ → ابزار سنگی → آهن → شکار/غذا =====
async function survivalStep() {
  if (isBusy) return // بذار دستور دستی که همین الان اجرا می‌شه اول تموم بشه
  try {
    if (!hasItem('wooden_pickaxe')) {
      if (countPlanksAndLogs() < 8) { await gatherWood(); return }
      if (!nearCraftingTable()) {
        if (!hasItem('crafting_table')) { await doCraft('crafting_table', 1); return }
        const placed = await placeCraftedBlock('crafting_table')
        if (!placed) await gatherWood()
        return
      }
      if (!hasItem('wooden_pickaxe')) { await doCraft('wooden_pickaxe', 1); return }
      if (!hasItem('wooden_sword')) { await doCraft('wooden_sword', 1); return }
      if (!hasItem('wooden_axe')) { await doCraft('wooden_axe', 1); return }
      return
    }

    if (!hasItem('stone_pickaxe')) {
      if (countItem('cobblestone') < 11) { await doCollect('stone', 11); return }
      if (!nearCraftingTable()) { await placeCraftedBlock('crafting_table'); return }
      if (!hasItem('stone_pickaxe')) { await doCraft('stone_pickaxe', 1); return }
      if (!hasItem('stone_sword')) { await doCraft('stone_sword', 1); return }
      if (!hasItem('stone_axe')) { await doCraft('stone_axe', 1); return }
      return
    }

    if (!hasItem('iron_pickaxe')) {
      const rawIron = countItem('raw_iron')
      const ingots = countItem('iron_ingot')
      if (rawIron + ingots < 6) { await doCollect('iron_ore', 6); return }
      if (rawIron > 0) { await smeltItems('raw_iron', rawIron); return }
      if (!nearCraftingTable()) { await placeCraftedBlock('crafting_table'); return }
      if (!hasItem('iron_pickaxe')) { await doCraft('iron_pickaxe', 1); return }
      if (!hasItem('iron_sword')) { await doCraft('iron_sword', 1); return }
      if (!hasItem('iron_axe')) { await doCraft('iron_axe', 1); return }
      return
    }

    // کیت آهنی کامله؛ حالا برای غذا شکار می‌کنه، وگرنه بیکار نمی‌مونه و چوب/سنگ اضافه جمع می‌کنه
    if (countCookedFood() < 6) { await huntForFood(); return }
    await gatherWood()
  } catch (e) {
    console.log('خطا توی مرحله‌ی سروایول:', e.message)
  }
}

// ===== نوشتن وضعیت زنده بات (جون، غذا، موقعیت، کار فعلی) برای نمایش توی برنامه =====
function startStatusReporting() {
  setInterval(() => {
    if (!bot || !bot.entity) return
    const status = {
      health: bot.health,
      food: bot.food,
      position: bot.entity.position ? {
        x: Math.round(bot.entity.position.x),
        y: Math.round(bot.entity.position.y),
        z: Math.round(bot.entity.position.z)
      } : null,
      heldItem: bot.heldItem ? bot.heldItem.name : null,
      currentAction,
      online: true,
      updatedAt: Date.now()
    }
    try { fs.writeFileSync(STATUS_FILE, JSON.stringify(status)) } catch (e) {}
  }, 2000)
}

function setAction(text) {
  currentAction = text
}

// ===== کنترل حرکت برای بات‌های «نمایش زنده» (وقتی CHAT_PASSTHROUGH فعاله) =====
// این کلمات رزرو شده‌ن؛ اگه دقیقاً همین‌ها رو تنها و تک‌کلمه بفرستی، به‌جای چت، بات حرکت می‌کنه.
const MOVE_COMMANDS = {
  'w': 'forward', 'جلو': 'forward',
  's': 'back', 'عقب': 'back',
  'a': 'left', 'چپ': 'left',
  'd': 'right', 'راست': 'right'
}
const JUMP_COMMANDS = ['space', 'jump', 'بپر']
const STOP_COMMANDS = ['stop', 'وایسا', 'توقف']
const SPRINT_ON_COMMANDS = ['sprint', 'دو', 'بدو']
const SPRINT_OFF_COMMANDS = ['walk', 'راه برو']
const LOOK_COMMANDS = {
  'چرخ راست': 0.4, 'turnright': 0.4,
  'چرخ چپ': -0.4, 'turnleft': -0.4
}
const PITCH_DOWN_COMMANDS = ['دوربین پایین', 'نگاه پایین', 'lookdown']
const PITCH_UP_COMMANDS = ['دوربین بالا', 'نگاه بالا', 'lookup']

function handleMovementCommand(text) {
  const lower = text.trim().toLowerCase()

  if (MOVE_COMMANDS[lower]) {
    bot.setControlState('forward', false)
    bot.setControlState('back', false)
    bot.setControlState('left', false)
    bot.setControlState('right', false)
    bot.setControlState(MOVE_COMMANDS[lower], true)
    console.log('🚶 در حال حرکت: ' + text)
    return true
  }
  if (JUMP_COMMANDS.includes(lower)) {
    bot.setControlState('jump', true)
    setTimeout(() => { if (bot) bot.setControlState('jump', false) }, 300)
    console.log('⬆️ پرید!')
    return true
  }
  if (STOP_COMMANDS.includes(lower)) {
    bot.clearControlStates()
    console.log('⏹ بات ایستاد.')
    return true
  }
  if (SPRINT_ON_COMMANDS.includes(lower)) {
    bot.setControlState('sprint', true)
    console.log('🏃 حالت دویدن روشن شد.')
    return true
  }
  if (SPRINT_OFF_COMMANDS.includes(lower)) {
    bot.setControlState('sprint', false)
    console.log('🚶 حالت دویدن خاموش شد.')
    return true
  }
  if (LOOK_COMMANDS[lower] !== undefined) {
    bot.look(bot.entity.yaw + LOOK_COMMANDS[lower], bot.entity.pitch, true)
    console.log('👀 چرخید.')
    return true
  }
  if (PITCH_DOWN_COMMANDS.includes(lower)) {
    bot.look(bot.entity.yaw, Math.min(bot.entity.pitch + 0.35, Math.PI / 2), true)
    console.log('👀 دوربین پایین اومد.')
    return true
  }
  if (PITCH_UP_COMMANDS.includes(lower)) {
    bot.look(bot.entity.yaw, Math.max(bot.entity.pitch - 0.35, -Math.PI / 2), true)
    console.log('👀 دوربین بالا رفت.')
    return true
  }
  return false
}

// ===== خوندن ورودی از پنجره کنسول =====
// اگه CHAT_PASSTHROUGH فعال باشه (بات‌های «نمایش زنده»)، اول چک می‌کنیم دستور حرکتی نیست؛
// اگه نبود، عیناً توی چت بازی گفته می‌شه.
// در غیر این‌صورت (بات‌های «متحرک»)، متن به‌عنوان دستور با کلمات کلیدی تفسیر می‌شه.
const rl = readline.createInterface({ input: process.stdin })
rl.on('line', async (line) => {
  const text = line.trim()
  if (!text || !bot) return
  if (text.startsWith('__CTRL__:')) {
    try { applyControlState(JSON.parse(text.slice('__CTRL__:'.length))) } catch (e) {}
    return
  }
  if (CHAT_PASSTHROUGH) {
    if (handleMovementCommand(text)) return
    // بات پیشرفته همه‌ی دستورهای بات متحرک رو هم می‌فهمه (حمله، جمع‌آوری، ساخت‌وساز، کرفت و...)
    // فقط اگه هیچ‌کدوم از این دستورها تشخیص داده نشد، متن عیناً توی چت بازی گفته می‌شه.
    const matched = COMMAND_PATTERNS.find((p) => p.test(text))
    if (matched) {
      await interpretAndRunCommand(text)
      return
    }
    try { bot.chat(text) } catch (e) { console.log('نتونستم پیام رو بفرستم:', e.message) }
    return
  }
  await interpretAndRunCommand(text)
})

// ===== کمک‌تابع: پیدا کردن اولین عدد توی متن =====
function extractNumber(text) {
  const m = text.match(/\d+/)
  return m ? parseInt(m[0], 10) : null
}

// ===== کمک‌تابع: پیدا کردن اسم بلوک (فارسی یا انگلیسی) توی متن =====
function extractBlockWord(text) {
  const words = text.split(/\s+/)
  for (const faWord of Object.keys(BLOCK_KEYWORDS)) {
    if (text.includes(faWord)) return faWord
  }
  // اگه فارسی نبود، آخرین کلمه‌ی معنادار متن رو به‌عنوان اسم بلوک انگلیسی در نظر می‌گیریم
  const stop = ['collect', 'gather', 'mine', 'get', 'me', 'a', 'some', 'blocks', 'block', 'جمع', 'کن', 'برو', 'بردار', 'کن.']
  const candidates = words.filter((w) => !stop.includes(w.toLowerCase()) && !/^\d+$/.test(w))
  return candidates.length ? candidates[candidates.length - 1] : null
}

// ===== کمک‌تابع: پیدا کردن یوزرنیم بعد از یه کلمه‌ی کلیدی خاص =====
function extractUsername(text) {
  // اگه یه کلمه شبیه یوزرنیم (بدون فاصله، حروف/عدد/آندرلاین) در متن بود همونو برمی‌گردونیم؛
  // اولویت با آخرین کلمه‌ی لاتین متن.
  const words = text.split(/\s+/).filter((w) => /^[A-Za-z0-9_]{2,16}$/.test(w))
  return words.length ? words[words.length - 1] : null
}

const COMMAND_PATTERNS = [
  {
    name: 'start_survival',
    test: (t) => /(شروع سروایول|شروع خودکار|start survival)/i.test(t)
  },
  {
    name: 'stop_survival',
    test: (t) => /(توقف سروایول|پایان سروایول|stop survival)/i.test(t)
  },
  {
    name: 'start_music',
    test: (t) => /(شروع آهنگ|پخش آهنگ|start music|play music)/i.test(t)
  },
  {
    name: 'stop_music',
    test: (t) => /(توقف آهنگ|قطع آهنگ|stop music)/i.test(t)
  },
  {
    name: 'stop',
    test: (t) => /(وایسا|توقف|بس ?کن|نگه ?دار|stop|halt)/i.test(t)
  },
  {
    name: 'follow_player',
    test: (t) => /(دنبال|بیا دنبالم|follow)/i.test(t)
  },
  {
    name: 'goto_player',
    test: (t) => /(بیا (پیش|کنار|سمت)|برو (پیش|کنار|سمت)|goto|come to)/i.test(t)
  },
  {
    name: 'attack',
    test: (t) => /(حمله|بزن|بکش|بجنگ|attack|kill|fight)/i.test(t)
  },
  {
    name: 'place_block',
    test: (t) => /(بلوک ?بذار|بلوک ?بگذار|place ?block)/i.test(t)
  },
  {
    name: 'build_wall',
    test: (t) => /(دیوار|build wall|wall)/i.test(t)
  },
  {
    name: 'craft_item',
    test: (t) => /(کرفت|بساز|craft)/i.test(t)
  },
  {
    name: 'equip_item',
    test: (t) => /(تجهیز|بپوش|equip|wield)/i.test(t)
  },
  {
    name: 'collect_block',
    test: (t) => /(جمع|جمع‌آوری|بردار|collect|gather|mine)/i.test(t)
  }
]

// ===== تفسیر دستور با کلمات کلیدی و اجرای عملیات مناسب (بدون هوش مصنوعی) =====
async function interpretAndRunCommand(text) {
  if (isBusy) {
    console.log('بات الان مشغول یه کار دیگه‌ست، صبر کن تموم بشه.')
    return
  }

  const match = COMMAND_PATTERNS.find((p) => p.test(text))
  if (!match) {
    console.log('این دستور رو نمی‌شناسم. دستورهای پشتیبانی‌شده: جمع‌آوری بلوک، برو پیش/دنبال کن فلان بازیکن، حمله، کرفت، دیوار بساز، تجهیز، وایسا.')
    return
  }

  isBusy = true
  try {
    if (match.name === 'collect_block') {
      const block = extractBlockWord(text)
      const count = extractNumber(text) || 5
      if (!block) { console.log('نفهمیدم چه بلوکی رو باید جمع کنم.'); return }
      setAction('جمع‌آوری ' + block)
      await doCollect(block, count)
    } else if (match.name === 'follow_player') {
      const username = extractUsername(text)
      if (!username) { console.log('یوزرنیم بازیکن رو توی دستور بنویس، مثلا: "دنبال Ali کن".'); return }
      setAction('دنبال کردن ' + username)
      doFollowPlayer(username)
    } else if (match.name === 'goto_player') {
      const username = extractUsername(text)
      if (!username) { console.log('یوزرنیم بازیکن رو توی دستور بنویس، مثلا: "برو پیش Ali".'); return }
      setAction('رفتن به سمت ' + username)
      await doGotoPlayer(username)
    } else if (match.name === 'attack') {
      const target = extractUsername(text) || extractMobWord(text)
      if (!target) { console.log('اسم بازیکن یا موجود مورد نظر رو بنویس، مثلا: "حمله به گوسفند".'); return }
      setAction('حمله به ' + target)
      try { bot.chat(pick(BATTLE_CRIES)) } catch (e) {}
      await doAttack(target)
    } else if (match.name === 'place_block') {
      setAction('گذاشتن بلوک')
      await doPlaceBlock()
    } else if (match.name === 'craft_item') {
      const item = extractLastEnglishWord(text)
      if (!item) { console.log('اسم انگلیسی آیتم رو بنویس، مثلا: "کرفت wooden_pickaxe".'); return }
      const count = extractNumber(text) || 1
      setAction('کرفت ' + item)
      await doCraft(item, count)
    } else if (match.name === 'build_wall') {
      const block = extractBlockWord(text)
      const length = extractNumber(text) || 5
      if (!block) { console.log('نفهمیدم دیوار رو از چه بلوکی بسازم.'); return }
      setAction('ساخت دیوار')
      await doBuildWall(block, length)
    } else if (match.name === 'equip_item') {
      const item = extractLastEnglishWord(text)
      if (!item) { console.log('اسم انگلیسی آیتم رو بنویس، مثلا: "تجهیز diamond_sword".'); return }
      await doEquip(item)
    } else if (match.name === 'stop') {
      bot.pathfinder.setGoal(null)
      setAction('بیکار')
      console.log('بات متوقف شد.')
    } else if (match.name === 'start_survival') {
      survivalModeActive = true
      if (!survivalLoopStarted) { survivalLoopStarted = true; survivalLoop() }
      setAction('سروایول خودکار')
      console.log('حالت سروایول خودکار (چوب→ابزار چوبی→سنگ→ابزار سنگی→آهن→شکار) شروع شد.')
    } else if (match.name === 'stop_survival') {
      survivalModeActive = false
      setAction('بیکار')
      console.log('حالت سروایول خودکار متوقف شد.')
    } else if (match.name === 'start_music') {
      musicActive = true
      if (!voiceChatLoopStarted) { voiceChatLoopStarted = true; runVoiceChatSequence() }
      console.log('پخش آهنگ شروع شد.')
    } else if (match.name === 'stop_music') {
      musicActive = false
      try { bot.chat('/simple_voice_radio stop') } catch (e) {}
      setAction('بیکار')
      console.log('پخش آهنگ متوقف شد.')
    }
  } catch (err) {
    console.log('خطا در اجرای دستور:', err.message)
  } finally {
    isBusy = false
    if (currentAction !== 'دنبال کردن') setAction('بیکار')
  }
}

function extractMobWord(text) {
  const matchedKey = Object.keys(MOB_KEYWORDS).find((fa) => text.includes(fa))
  if (matchedKey) return matchedKey
  return null
}

function extractLastEnglishWord(text) {
  const words = text.split(/\s+/).filter((w) => /^[A-Za-z_]+$/.test(w))
  return words.length ? words[words.length - 1].toLowerCase() : null
}

// ===== عملیات: جمع‌آوری بلوک =====
async function doCollect(blockText, count) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  console.log(`در حال پیدا کردن و جمع‌آوری ${blockText} (تا ${count} عدد)...`)
  const blocks = bot.findBlocks({ matching: (b) => b.name.includes(blockKeyword), maxDistance: 64, count })
  if (blocks.length === 0) {
    console.log(`هیچ بلوکی از نوع "${blockText}" توی نزدیکی پیدا نشد.`)
    return
  }
  const blockObjects = blocks.map((pos) => bot.blockAt(pos)).filter(Boolean)
  await bot.collectBlock.collect(blockObjects, { ignoreNoPath: false })
  console.log(`${blockText} با موفقیت جمع‌آوری شد!`)
}

// ===== عملیات: رفتن یک‌باره به سمت بازیکن =====
async function doGotoPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم (شاید آنلاین نیست یا خیلی دوره).`)
    return
  }
  console.log(`در حال رفتن به سمت ${username}...`)
  const pos = player.entity.position
  await bot.pathfinder.goto(new goals.GoalNear(pos.x, pos.y, pos.z, 2))
  console.log(`به ${username} رسیدم.`)
}

// ===== عملیات: دنبال کردن پیوسته =====
function doFollowPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم.`)
    return
  }
  console.log(`در حال دنبال کردن ${username}... (برای توقف بگو "وایسا")`)
  bot.pathfinder.setGoal(new goals.GoalFollow(player.entity, 2), true)
}

// ===== عملیات: ارسال پیام =====
function doSendMessage(username, message) {
  bot.whisper(username, message)
  console.log(`پیام به ${username} ارسال شد: ${message}`)
}

// ===== تجهیز بهترین سلاح موجود قبل از حمله =====
async function equipBestWeapon() {
  // ترتیب تراز کیفیت سلاح‌ها؛ شمشیر همیشه به تبر ترجیح داده می‌شه
  const TIER_ORDER = ['netherite', 'diamond', 'iron', 'golden', 'stone', 'wooden']
  const rank = (name) => {
    const i = TIER_ORDER.findIndex((t) => name.startsWith(t))
    return i === -1 ? 99 : i
  }
  const items = bot.inventory.items()
  const swords = items.filter((i) => i.name.endsWith('_sword'))
  const axes = items.filter((i) => i.name.endsWith('_axe'))
  const pool = swords.length ? swords : axes
  if (pool.length === 0) return
  pool.sort((a, b) => rank(a.name) - rank(b.name))
  try { await bot.equip(pool[0], 'hand') } catch (e) {}
}

async function doEquip(itemName) {
  const item = bot.inventory.items().find((i) => i.name.includes(itemName.toLowerCase()))
  if (!item) {
    console.log(`آیتم "${itemName}" توی اینونتوری پیدا نشد.`)
    return
  }
  await bot.equip(item, 'hand')
  console.log(`${itemName} تجهیز شد.`)
}

// ===== عملیات: حمله (با تجهیز خودکار سلاح و ردیابی پایدارتر هدف) =====
async function findEntityByTarget(target) {
  const player = bot.players[target]
  if (player && player.entity) return player.entity
  const matchedKey = Object.keys(MOB_KEYWORDS).find((fa) => target.includes(fa) || fa.includes(target))
  const mobType = matchedKey ? MOB_KEYWORDS[matchedKey] : target.toLowerCase()
  return bot.nearestEntity((e) => e.name && e.name.toLowerCase().includes(mobType))
}

async function doAttack(target) {
  await equipBestWeapon()
  let entity = await findEntityByTarget(target)

  if (!entity) {
    console.log(`چیزی به اسم یا نوع "${target}" پیدا نکردم.`)
    return
  }

  console.log(`در حال حمله به ${target}...`)
  const startTime = Date.now()
  const maxDurationMs = 5 * 60 * 1000 // سقف کلی، تا حمله بی‌نهایت طول نکشه
  const loseSightGraceMs = 12000 // اگه هدف چند لحظه از دید/محدوده خارج بشه، این‌قدر صبر می‌کنیم قبل از تسلیم
  let lastSeenAt = Date.now()
  let lastKnownPos = entity.position.clone ? entity.position.clone() : entity.position

  while (Date.now() - startTime < maxDurationMs) {
    // هر بار دوباره موجودیت رو بر اساس اسم/نوع پیدا می‌کنیم (نه فقط تکیه به آبجکت قدیمی)
    const fresh = bot.entities[entity.id] || (await findEntityByTarget(target))

    if (fresh) {
      entity = fresh
      lastSeenAt = Date.now()
      lastKnownPos = entity.position.clone ? entity.position.clone() : entity.position

      const dist = bot.entity.position.distanceTo(entity.position)
      if (dist > 3) {
        try {
          await bot.pathfinder.goto(new goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2))
        } catch (e) { /* ممکنه مسیر لحظه‌ای قطع بشه، مشکلی نیست، دور بعد دوباره تلاش می‌کنیم */ }
      } else {
        bot.attack(entity)
        await new Promise((r) => setTimeout(r, 650))
      }
    } else {
      // هدف موقتاً از محدوده‌ی دید خارج شده — به‌جای تسلیم فوری، تا مدتی صبر می‌کنیم و سعی می‌کنیم پیداش کنیم
      if (Date.now() - lastSeenAt > loseSightGraceMs) {
        console.log(`${target} رو گم کردم و نتونستم دوباره پیداش کنم.`)
        return
      }
      try {
        await bot.pathfinder.goto(new goals.GoalNear(lastKnownPos.x, lastKnownPos.y, lastKnownPos.z, 2))
      } catch (e) {}
      await new Promise((r) => setTimeout(r, 400))
    }

    if (bot.health <= 0) return
  }
  console.log(`حمله به ${target} تموم شد.`)
}

// ===== عملیات: کرفت آیتم =====
async function doCraft(itemName, count) {
  const mcData = require('minecraft-data')(bot.version)
  const item = mcData.itemsByName[itemName]
  if (!item) {
    console.log(`آیتمی به اسم "${itemName}" نمی‌شناسم.`)
    return
  }

  let craftingTable = bot.findBlock({ matching: mcData.blocksByName.crafting_table?.id, maxDistance: 16 })
  const recipes = bot.recipesFor(item.id, null, 1, craftingTable)

  if (recipes.length === 0) {
    console.log(`الان نمی‌تونم "${itemName}" رو کرفت کنم (شاید مواد کافی نیست یا به کرفتینگ تیبل نیاز داره).`)
    return
  }

  console.log(`در حال کرفت ${itemName}...`)
  await bot.craft(recipes[0], count, craftingTable)
  console.log(`${itemName} با موفقیت کرفت شد!`)
}

// ===== عملیات: گذاشتن یه بلوک، همونی که الان دستته، جلوی پای بات =====
async function doPlaceBlock() {
  const item = bot.heldItem
  if (!item) {
    console.log('چیزی دستت نیست که بذاری. اول با «تجهیز» یه بلوک دست بگیر.')
    return
  }
  const refBlock = bot.blockAt(bot.entity.position.offset(0, -1, 0))
  if (!refBlock) {
    console.log('بلوک زیر پام رو پیدا نکردم.')
    return
  }
  try {
    await bot.placeBlock(refBlock, { x: 0, y: 1, z: 0 })
    console.log(`بلوک ${item.name} گذاشته شد.`)
  } catch (e) {
    console.log('نتونستم بلوک رو بذارم:', e.message)
  }
}

// ===== عملیات: ساخت دیوار ساده =====
async function doBuildWall(blockText, length) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  const item = bot.inventory.items().find((i) => i.name.includes(blockKeyword))
  if (!item) {
    console.log(`بلوک "${blockText}" توی اینونتوری نداری.`)
    return
  }

  console.log(`در حال ساخت دیوار به طول ${length}...`)
  await bot.equip(item, 'hand')
  const startPos = bot.entity.position.floored()
  const dir = bot.entity.yaw

  for (let i = 0; i < length; i++) {
    const targetPos = startPos.offset(i, 0, 0)
    const refBlock = bot.blockAt(targetPos.offset(0, -1, 0))
    if (!refBlock) continue
    try {
      await bot.placeBlock(refBlock, { x: 0, y: 1, z: 0 })
    } catch (e) {
      console.log(`نتونستم بلوک شماره ${i + 1} رو بذارم: ${e.message}`)
    }
  }
  console.log('ساخت دیوار تموم شد.')
}

// =====================================================================
// ===== چت رایگان بدون هوش مصنوعی: پاسخ‌های متنوع و طبیعی‌تر =====
// =====================================================================
//
// به‌جای یک جواب ثابت برای هر دسته، چند نسخه‌ی مختلف داریم که هر بار
// تصادفی انتخاب می‌شن. همچنین از حافظه‌ی مکالمه استفاده می‌کنیم تا
// اگه بازیکن قبلاً حرف زده، بات یه‌جوری بهش اشاره کنه (بدون اینکه واقعاً
// «بفهمه» چی گفته بوده — فقط برای طبیعی‌تر شدن حس مکالمه).

const REPLIES = {
  fa: {
    greeting: [
      'سلام رفیق! چه خبرا؟',
      'سلاام 👋 خوش اومدی',
      'اِاِ سلام! امروز حالت چطوره؟',
      'سلام سلام، اینجا چیکار می‌کنی؟ 😄'
    ],
    greetingReturning: [
      'باز اومدی سراغم! خوشحالم می‌بینمت 😊',
      'اِ باز تو! خوش برگشتی رفیق',
      'سلام دوباره! دلم برات تنگ شده بود توی این سرور 😂'
    ],
    howAreYou: [
      'بد نیستم، سرم شلوغه ولی حالم خوبه. تو چطوری؟',
      'عالیم! دارم می‌گردم دنبال چندتا بلوک. تو خوبی؟',
      'خوبم مرسی که پرسیدی 🙂 خودت چطوری؟'
    ],
    thanks: [
      'خواهش می‌کنم رفیق 😊',
      'قابلی نداشت!',
      'وظیفه‌ست، هر وقت خواستی صدام کن.'
    ],
    bye: [
      'باشه، بعداً می‌بینمت 👋',
      'خدافظ! مواظب خودت باش',
      'فعلاً! اگه کاری داشتی بازم پیام بده.'
    ],
    aboutServer: [
      'این یکی از بهترین سرورهای دنیاست به نظرم!',
      'سرور خیلی خوبیه، من که عاشقشم 😄',
      'راستش رو بخوای، از بهترین سرورهایی‌ه که دیدم.'
    ],
    praise: [
      'وا ممنون، لطف داری 😊',
      'خیلی مهربونی، مرسی!',
      'قربونت، خوشحال شدم شنیدم 🙏'
    ],
    insultOrNegative: [
      'اوه، شرمنده اگه اذیت‌کننده بودم. بگو چیکار کنم بهتر بشه.',
      'باشه بابا، آروم 😅 چیزی لازم داری؟',
      'اوکی، جدی نمی‌گیرم. کاری هست کمکت کنم؟'
    ],
    askWhoAreYou: [
      'من یه بات ماینکرفتم که اینجا کمک می‌کنم — جمع‌آوری، ساخت‌وساز، دنبال کردن و از این کارا.',
      'یه بات دستیارم! می‌تونم برات بلوک جمع کنم، دنبالت بیام، بسازم و خیلی کارای دیگه.',
      'بات این سرورم، برای کمک به بازیکن‌ها اینجام 🙂'
    ],
    unknown: [
      'دقیق متوجه نشدم چی گفتی، یه‌جور دیگه بگو؟',
      'هوم، نفهمیدم منظورت چیه، می‌شه واضح‌تر بگی؟',
      'یه‌کم گنگ بود برام 😅 دوباره امتحان کن.',
      'نتونستم بفهممش، ولی اگه دستوری داری بگو انجامش می‌دم.'
    ]
  },
  en: {
    greeting: [
      'Hey there! What\'s up?',
      'Heyy 👋 good to see you',
      'Oh hi! How\'s it going today?',
      'Hello hello, what brings you here? 😄'
    ],
    greetingReturning: [
      'You\'re back! Good to see you again 😊',
      'Oh hey, welcome back!',
      'Hi again! Missed you around here 😂'
    ],
    howAreYou: [
      'Not bad, a bit busy but doing fine. How about you?',
      'I\'m great! Just out looking for some blocks. You good?',
      'Doing well, thanks for asking 🙂 How are you?'
    ],
    thanks: [
      'No problem at all 😊',
      'Anytime!',
      'You got it, happy to help.'
    ],
    bye: [
      'Alright, see you around 👋',
      'Bye! Take care',
      'Later! Ping me if you need anything.'
    ],
    aboutServer: [
      'This is honestly one of the best servers around!',
      'Great server, I really like it here 😄',
      'One of the best I\'ve seen, for sure.'
    ],
    praise: [
      'Aw thanks, that\'s sweet of you 😊',
      'You\'re too kind, thank you!',
      'Appreciate that, made my day 🙏'
    ],
    insultOrNegative: [
      'Sorry if that was annoying. Let me know what you need.',
      'Alright, no worries 😅 anything I can help with?',
      'Okay, taking that lightly. Need something?'
    ],
    askWhoAreYou: [
      'I\'m a Minecraft helper bot — I gather stuff, build, follow you around, that kind of thing.',
      'Just an assistant bot! I can collect blocks, follow, craft, and more.',
      'I\'m this server\'s bot, here to help players out 🙂'
    ],
    unknown: [
      'Not sure I got that, could you say it differently?',
      'Hmm, not quite following — mind rephrasing?',
      'That was a bit unclear to me 😅 try again?',
      'Couldn\'t quite parse that, but if it\'s a command just tell me directly.'
    ]
  }
}

const PATTERNS = {
  greeting: /^(سلام+|درود|hi+|hello+|hey+|yo)\b/i,
  howAreYou: /(چطوری|حالت چطوره|خوبی\??|how are you|hows it going|how('| i)?s it going)/i,
  thanks: /(ممنون|مرسی|تشکر|thanks|thank you|thx)/i,
  bye: /(خداحافظ|بای|فعلا|bye|goodbye|see ya|cya)/i,
  aboutServer: /(سرور.*(چطور|خوبه)|این سرور|about (this|the) server|this server)/i,
  praise: /(خیلی خوبی|عالی هستی|دمت گرم|good bot|nice bot|you('| a)?re (great|awesome|cool))/i,
  insultOrNegative: /(احمق|بی‌شعور|خنگ|stupid|dumb|idiot|useless)/i,
  askWhoAreYou: /(تو کی هستی|چی هستی|who are you|what are you)/i
}

function getChatReply(username, userMessage) {
  const persian = isPersianText(userMessage)
  const lang = persian ? REPLIES.fa : REPLIES.en

  if (!conversationHistory[username]) conversationHistory[username] = []
  const history = conversationHistory[username]
  const isReturning = history.length > 0

  let category = 'unknown'
  for (const key of Object.keys(PATTERNS)) {
    if (PATTERNS[key].test(userMessage)) { category = key; break }
  }

  let reply
  if (category === 'greeting' && isReturning) {
    reply = pick(lang.greetingReturning)
  } else {
    reply = pick(lang[category])
  }

  history.push({ from: userMessage, reply, at: Date.now() })
  if (history.length > 20) history.splice(0, history.length - 20)
  saveMemory()

  return reply
}

function sendLongWhisper(username, text) {
  const maxLen = 200
  for (let i = 0; i < text.length; i += maxLen) bot.whisper(username, text.slice(i, i + maxLen))
}
