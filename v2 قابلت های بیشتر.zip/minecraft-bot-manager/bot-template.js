// bot.js — به‌صورت خودکار توسط برنامه ساخته شده
// نسخه‌ی بدون هوش مصنوعی: هیچ API خارجی صدا زده نمی‌شه، همه‌چیز قانون‌محور (rule-based) و رایگانه.

// ===== جلوگیری از کرش خام: این‌ها باید قبل از هر require دیگه‌ای ثبت بشن =====
// اگه پکیج‌ها ناقص نصب شده باشن، require زیر پرتاب خطا می‌کنه؛ این try/catch
// به‌جای یه استک‌تریس خام، یه پیام فارسی روشن نشون می‌ده و پروسه رو تمیز می‌بنده.
process.on('uncaughtException', (err) => {
  console.log('❌ خطای مدیریت‌نشده:', err && err.message)
})
process.on('unhandledRejection', (err) => {
  console.log('❌ خطای Promise مدیریت‌نشده:', err && err.message)
})

let mineflayer, pathfinder, Movements, goals, collectBlockPlugin, autoEatPlugin
try {
  mineflayer = require('mineflayer')
  ;({ pathfinder, Movements, goals } = require('mineflayer-pathfinder'))
  collectBlockPlugin = require('mineflayer-collectblock').plugin
  ;({ plugin: autoEatPlugin } = require('mineflayer-auto-eat'))
} catch (err) {
  console.log('❌ پکیج‌های موردنیاز کامل نصب نشدن (' + err.message + ').')
  console.log('این بات رو حذف کن و دوباره بساز، یا از دکمه‌ی «نصب مجدد پکیج‌ها» استفاده کن.')
  process.exit(1)
}
const readline = require('readline')
const fs = require('fs')
const path = require('path')

const BOT_DIR = __dirname
const MEMORY_FILE = path.join(BOT_DIR, 'memory.json')
const STATUS_FILE = path.join(BOT_DIR, 'status.json')

// ===== تنظیمات (توسط برنامه پر می‌شه) =====
const LOGIN_PASSWORD = {{LOGIN_PASSWORD}}
const HOST = {{HOST}}
const PORT = {{PORT}}
const USERNAME = {{USERNAME}}
const VERSION = {{VERSION}}
// وقتی true باشه: هرچی توی کنسول تایپ کنی عیناً توی چت بازی گفته می‌شه (به‌جای تفسیر به‌عنوان دستور)
const CHAT_PASSTHROUGH = {{CHAT_PASSTHROUGH}}
// وقتی true باشه: بعد از مرگ، خودکار توی چت "/lobby" می‌فرسته
const GOTO_LOBBY_ON_DEATH = {{GOTO_LOBBY_ON_DEATH}}
// وقتی true باشه: یه نمایشگر زنده (توی مرورگر) از دید بات راه‌اندازی می‌شه
const LIVE_VIEWER = {{LIVE_VIEWER}}
const VIEWER_PORT = {{VIEWER_PORT}}
// وقتی true باشه: بات خودش وارد سروایول می‌شه، رندوم تلپورت می‌شه، خودکار چوب جمع می‌کنه
// و اگه بهش حمله بشه از خودش دفاع می‌کنه — بدون کنترل دستی، فقط با نمایشگر زنده قابل تماشاست
const SURVIVAL_MODE = {{SURVIVAL_MODE}}

let reconnectAttempts = 0
const MAX_RECONNECT_DELAY_MS = 60000


// ===== تشخیص زبان متن (فقط برای انتخاب زبان پاسخ، بدون نیاز به API) =====
function isPersianText(text) {
  return /[\u0600-\u06FF]/.test(text)
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

// نگاشت اسم فارسی بلوک‌ها به کلمه کلیدی داخل اسم انگلیسی بلوک
const BLOCK_KEYWORDS = {
  'چوب': 'log', 'هیزم': 'log', 'سنگ': 'stone', 'خاک': 'dirt', 'شن': 'sand',
  'شنریزه': 'gravel', 'سنگریزه': 'gravel', 'چمن': 'grass_block', 'زغال': 'coal_ore',
  'آهن': 'iron_ore', 'طلا': 'gold_ore', 'الماس': 'diamond_ore', 'برگ': 'leaves',
  'کوارتز': 'quartz', 'ردستون': 'redstone_ore', 'لاپیس': 'lapis_ore'
}

// نگاشت اسم فارسی موجودات به اسم انگلیسی برای حمله
const MOB_KEYWORDS = {
  'گوسفند': 'sheep', 'گاو': 'cow', 'خوک': 'pig', 'مرغ': 'chicken', 'جوجه': 'chicken',
  'زامبی': 'zombie', 'اسکلت': 'skeleton', 'کریپر': 'creeper', 'عنکبوت': 'spider',
  'اندرمن': 'enderman', 'خفاش': 'bat', 'اسب': 'horse'
}

// ===== حافظه‌ی بلندمدت مکالمه (بین ری‌استارت‌ها هم می‌مونه) =====
let conversationHistory = {}
try {
  if (fs.existsSync(MEMORY_FILE)) {
    conversationHistory = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'))
  }
} catch (e) {
  console.log('نتونستم حافظه‌ی قبلی رو بخونم، از صفر شروع می‌کنم.')
}
function saveMemory() {
  try { fs.writeFileSync(MEMORY_FILE, JSON.stringify(conversationHistory)) } catch (e) {}
}

let bot
let isBusy = false
let currentAction = 'بیکار'
let survivalLoopStarted = false
let inCombat = false
function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)) }

function createBot() {
  bot = mineflayer.createBot({ host: HOST, port: PORT, username: USERNAME, version: VERSION })
  bot.loadPlugin(pathfinder)
  bot.loadPlugin(collectBlockPlugin)
  bot.loadPlugin(autoEatPlugin)

  bot.on('spawn', () => {
    console.log('بات وارد بازی شد!')
    reconnectAttempts = 0
    try {
      bot.pathfinder.setMovements(new Movements(bot))
    } catch (e) {
      console.log('⚠️ راه‌اندازی مسیریابی با خطا مواجه شد:', e.message)
    }

    // ===== غذا خوردن خودکار وقتی گرسنه می‌شه =====
    try {
      bot.autoEat.options = { priority: 'foodPoints', startAt: 16, bannedFood: [] }
    } catch (e) {
      console.log('⚠️ راه‌اندازی غذاخوردن خودکار با خطا مواجه شد:', e.message)
    }

    setTimeout(() => bot.chat(`/register ${LOGIN_PASSWORD} ${LOGIN_PASSWORD}`), 1000)
    setTimeout(() => bot.chat(`/login ${LOGIN_PASSWORD}`), 2500)

    if (LIVE_VIEWER) {
      try {
        require('prismarine-viewer').mineflayer(bot, { port: VIEWER_PORT, firstPerson: true })
        console.log(`🖥 نمایش زنده در دسترسه: http://localhost:${VIEWER_PORT}`)
      } catch (e) {
        console.log('⚠️ نمایشگر زنده راه‌اندازی نشد:', e.message)
      }
    }

    if (SURVIVAL_MODE && !survivalLoopStarted) {
      survivalLoopStarted = true
      runSurvivalSequence()
    }

    startStatusReporting()
  })

  bot.on('whisper', async (username, message) => {
    if (username === bot.username) return
    const userMessage = message.trim()
    if (!userMessage) return
    try {
      const reply = getChatReply(username, userMessage)
      sendLongWhisper(username, reply)
    } catch (err) {
      console.error('خطا در تولید پاسخ:', err.message)
      bot.whisper(username, 'ببخشید، الان نمی‌تونم جواب بدم :(')
    }
  })

  bot.on('health', () => {
    if (bot.health <= 6) console.log(`⚠️ جون بات کمه: ${bot.health}/20`)
  })

  bot.on('death', () => {
    console.log('بات مرد.')
    if (GOTO_LOBBY_ON_DEATH) {
      setTimeout(() => { try { bot.chat('/lobby') } catch (e) {} }, 1000)
    }
    if (SURVIVAL_MODE) {
      // بعد از مرگ، سرور معمولاً خودکار ریسپان می‌کنه؛ یه‌کم صبر می‌کنیم و کار رو ادامه می‌دیم
      setTimeout(() => { try { bot.respawn && bot.respawn() } catch (e) {} }, 1500)
    }
  })

  // ===== دفاع از خود در حالت سروایول: اگه بهش حمله بشه، طرف رو می‌زنه =====
  bot.on('entityHurt', async (entity) => {
    if (!SURVIVAL_MODE || !bot.entity || inCombat) return
    if (!entity || entity.id !== bot.entity.id) return

    const attacker = bot.nearestEntity((e) => e.type === 'player' && e !== bot.entity && bot.entity.position.distanceTo(e.position) < 6)
    if (!attacker) return

    inCombat = true
    setAction('دفاع از خود در برابر ' + (attacker.username || 'حمله‌کننده'))
    try {
      await equipBestWeapon()
      const startTime = Date.now()
      const maxDurationMs = 30000
      const loseSightGraceMs = 8000
      let target = attacker
      let lastSeenAt = Date.now()

      while (Date.now() - startTime < maxDurationMs) {
        const fresh = bot.entities[target.id]
        if (fresh) {
          target = fresh
          lastSeenAt = Date.now()
          const dist = bot.entity.position.distanceTo(target.position)
          if (dist > 3) {
            try { await bot.pathfinder.goto(new goals.GoalNear(target.position.x, target.position.y, target.position.z, 2)) } catch (e) {}
          } else {
            bot.attack(target)
            await sleep(600)
          }
        } else {
          if (Date.now() - lastSeenAt > loseSightGraceMs) break
          await sleep(400)
        }
        if (bot.health <= 0) break
      }
    } catch (e) {
      console.log('خطا توی دفاع از خود:', e.message)
    }
    inCombat = false
    setAction('سروایول خودکار')
  })

  bot.on('error', (err) => console.log('خطا:', err.message))
  bot.on('kicked', (reason) => console.log('اخراج شد:', reason))


  bot.on('end', () => {
    reconnectAttempts++
    const delay = Math.min(10000 * reconnectAttempts, MAX_RECONNECT_DELAY_MS)
    console.log(`اتصال قطع شد. تلاش مجدد تا ${delay / 1000} ثانیه دیگه...`)
    setTimeout(createBot, delay)
  })
}

createBot()

// ===== حلقه‌ی خودکار حالت سروایول (بدون کنترل دستی) =====
async function runSurvivalSequence() {
  try {
    await sleep(2000)
    bot.chat('/survival')
    await sleep(2500)
    bot.chat('/rtp')
    await sleep(4000)
    setAction('سروایول خودکار')
    survivalLoop()
  } catch (e) {
    console.log('خطا در شروع حالت سروایول:', e.message)
  }
}

async function survivalLoop() {
  while (SURVIVAL_MODE && bot) {
    if (inCombat) { await sleep(500); continue }
    try {
      const blocks = bot.findBlocks({ matching: (b) => b.name.includes('log'), maxDistance: 48, count: 1 })
      if (blocks.length > 0) {
        const blockObj = bot.blockAt(blocks[0])
        if (blockObj) {
          try {
            await bot.collectBlock.collect(blockObj, { ignoreNoPath: true })
          } catch (e) { /* مسیر لحظه‌ای نبود یا کسی زودتر برداشت، مشکلی نیست */ }
        }
      } else {
        // درختی نزدیک نبود؛ یه جهت رندوم می‌ره تا دنبال درخت جدید بگرده
        const angle = Math.random() * Math.PI * 2
        const dist = 15 + Math.random() * 15
        const t = bot.entity.position.offset(Math.cos(angle) * dist, 0, Math.sin(angle) * dist)
        try {
          await bot.pathfinder.goto(new goals.GoalNear(t.x, t.y, t.z, 2))
        } catch (e) {}
      }
    } catch (e) {
      console.log('خطا توی حلقه‌ی سروایول:', e.message)
    }
    await sleep(1000)
  }
}

// ===== نوشتن وضعیت زنده بات (جون، غذا، موقعیت، کار فعلی) برای نمایش توی برنامه =====
function startStatusReporting() {
  setInterval(() => {
    if (!bot || !bot.entity) return
    const status = {
      health: bot.health,
      food: bot.food,
      position: bot.entity.position ? {
        x: Math.round(bot.entity.position.x),
        y: Math.round(bot.entity.position.y),
        z: Math.round(bot.entity.position.z)
      } : null,
      heldItem: bot.heldItem ? bot.heldItem.name : null,
      currentAction,
      online: true,
      updatedAt: Date.now()
    }
    try { fs.writeFileSync(STATUS_FILE, JSON.stringify(status)) } catch (e) {}
  }, 2000)
}

function setAction(text) {
  currentAction = text
}

// ===== خوندن ورودی از پنجره کنسول =====
// اگه CHAT_PASSTHROUGH فعال باشه (بات‌های «نمایش زنده»)، هرچی تایپ کنی عیناً توی چت بازی گفته می‌شه.
// در غیر این‌صورت (بات‌های «متحرک»)، متن به‌عنوان دستور با کلمات کلیدی تفسیر می‌شه.
const rl = readline.createInterface({ input: process.stdin })
rl.on('line', async (line) => {
  const text = line.trim()
  if (!text || !bot) return
  if (CHAT_PASSTHROUGH) {
    try { bot.chat(text) } catch (e) { console.log('نتونستم پیام رو بفرستم:', e.message) }
    return
  }
  await interpretAndRunCommand(text)
})

// ===== کمک‌تابع: پیدا کردن اولین عدد توی متن =====
function extractNumber(text) {
  const m = text.match(/\d+/)
  return m ? parseInt(m[0], 10) : null
}

// ===== کمک‌تابع: پیدا کردن اسم بلوک (فارسی یا انگلیسی) توی متن =====
function extractBlockWord(text) {
  const words = text.split(/\s+/)
  for (const faWord of Object.keys(BLOCK_KEYWORDS)) {
    if (text.includes(faWord)) return faWord
  }
  // اگه فارسی نبود، آخرین کلمه‌ی معنادار متن رو به‌عنوان اسم بلوک انگلیسی در نظر می‌گیریم
  const stop = ['collect', 'gather', 'mine', 'get', 'me', 'a', 'some', 'blocks', 'block', 'جمع', 'کن', 'برو', 'بردار', 'کن.']
  const candidates = words.filter((w) => !stop.includes(w.toLowerCase()) && !/^\d+$/.test(w))
  return candidates.length ? candidates[candidates.length - 1] : null
}

// ===== کمک‌تابع: پیدا کردن یوزرنیم بعد از یه کلمه‌ی کلیدی خاص =====
function extractUsername(text) {
  // اگه یه کلمه شبیه یوزرنیم (بدون فاصله، حروف/عدد/آندرلاین) در متن بود همونو برمی‌گردونیم؛
  // اولویت با آخرین کلمه‌ی لاتین متن.
  const words = text.split(/\s+/).filter((w) => /^[A-Za-z0-9_]{2,16}$/.test(w))
  return words.length ? words[words.length - 1] : null
}

const COMMAND_PATTERNS = [
  {
    name: 'stop',
    test: (t) => /(وایسا|توقف|بس ?کن|نگه ?دار|stop|halt)/i.test(t)
  },
  {
    name: 'follow_player',
    test: (t) => /(دنبال|بیا دنبالم|follow)/i.test(t)
  },
  {
    name: 'goto_player',
    test: (t) => /(بیا (پیش|کنار|سمت)|برو (پیش|کنار|سمت)|goto|come to)/i.test(t)
  },
  {
    name: 'attack',
    test: (t) => /(حمله|بزن|بکش|attack|kill)/i.test(t)
  },
  {
    name: 'build_wall',
    test: (t) => /(دیوار|build wall|wall)/i.test(t)
  },
  {
    name: 'craft_item',
    test: (t) => /(کرفت|بساز|craft)/i.test(t)
  },
  {
    name: 'equip_item',
    test: (t) => /(تجهیز|بپوش|equip|wield)/i.test(t)
  },
  {
    name: 'collect_block',
    test: (t) => /(جمع|جمع‌آوری|بردار|collect|gather|mine)/i.test(t)
  }
]

// ===== تفسیر دستور با کلمات کلیدی و اجرای عملیات مناسب (بدون هوش مصنوعی) =====
async function interpretAndRunCommand(text) {
  if (isBusy) {
    console.log('بات الان مشغول یه کار دیگه‌ست، صبر کن تموم بشه.')
    return
  }

  const match = COMMAND_PATTERNS.find((p) => p.test(text))
  if (!match) {
    console.log('این دستور رو نمی‌شناسم. دستورهای پشتیبانی‌شده: جمع‌آوری بلوک، برو پیش/دنبال کن فلان بازیکن، حمله، کرفت، دیوار بساز، تجهیز، وایسا.')
    return
  }

  isBusy = true
  try {
    if (match.name === 'collect_block') {
      const block = extractBlockWord(text)
      const count = extractNumber(text) || 5
      if (!block) { console.log('نفهمیدم چه بلوکی رو باید جمع کنم.'); return }
      setAction('جمع‌آوری ' + block)
      await doCollect(block, count)
    } else if (match.name === 'follow_player') {
      const username = extractUsername(text)
      if (!username) { console.log('یوزرنیم بازیکن رو توی دستور بنویس، مثلا: "دنبال Ali کن".'); return }
      setAction('دنبال کردن ' + username)
      doFollowPlayer(username)
    } else if (match.name === 'goto_player') {
      const username = extractUsername(text)
      if (!username) { console.log('یوزرنیم بازیکن رو توی دستور بنویس، مثلا: "برو پیش Ali".'); return }
      setAction('رفتن به سمت ' + username)
      await doGotoPlayer(username)
    } else if (match.name === 'attack') {
      const target = extractUsername(text) || extractMobWord(text)
      if (!target) { console.log('اسم بازیکن یا موجود مورد نظر رو بنویس، مثلا: "حمله به گوسفند".'); return }
      setAction('حمله به ' + target)
      await doAttack(target)
    } else if (match.name === 'craft_item') {
      const item = extractLastEnglishWord(text)
      if (!item) { console.log('اسم انگلیسی آیتم رو بنویس، مثلا: "کرفت wooden_pickaxe".'); return }
      const count = extractNumber(text) || 1
      setAction('کرفت ' + item)
      await doCraft(item, count)
    } else if (match.name === 'build_wall') {
      const block = extractBlockWord(text)
      const length = extractNumber(text) || 5
      if (!block) { console.log('نفهمیدم دیوار رو از چه بلوکی بسازم.'); return }
      setAction('ساخت دیوار')
      await doBuildWall(block, length)
    } else if (match.name === 'equip_item') {
      const item = extractLastEnglishWord(text)
      if (!item) { console.log('اسم انگلیسی آیتم رو بنویس، مثلا: "تجهیز diamond_sword".'); return }
      await doEquip(item)
    } else if (match.name === 'stop') {
      bot.pathfinder.setGoal(null)
      setAction('بیکار')
      console.log('بات متوقف شد.')
    }
  } catch (err) {
    console.log('خطا در اجرای دستور:', err.message)
  } finally {
    isBusy = false
    if (currentAction !== 'دنبال کردن') setAction('بیکار')
  }
}

function extractMobWord(text) {
  const matchedKey = Object.keys(MOB_KEYWORDS).find((fa) => text.includes(fa))
  if (matchedKey) return matchedKey
  return null
}

function extractLastEnglishWord(text) {
  const words = text.split(/\s+/).filter((w) => /^[A-Za-z_]+$/.test(w))
  return words.length ? words[words.length - 1].toLowerCase() : null
}

// ===== عملیات: جمع‌آوری بلوک =====
async function doCollect(blockText, count) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  console.log(`در حال پیدا کردن و جمع‌آوری ${blockText} (تا ${count} عدد)...`)
  const blocks = bot.findBlocks({ matching: (b) => b.name.includes(blockKeyword), maxDistance: 64, count })
  if (blocks.length === 0) {
    console.log(`هیچ بلوکی از نوع "${blockText}" توی نزدیکی پیدا نشد.`)
    return
  }
  const blockObjects = blocks.map((pos) => bot.blockAt(pos)).filter(Boolean)
  await bot.collectBlock.collect(blockObjects, { ignoreNoPath: false })
  console.log(`${blockText} با موفقیت جمع‌آوری شد!`)
}

// ===== عملیات: رفتن یک‌باره به سمت بازیکن =====
async function doGotoPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم (شاید آنلاین نیست یا خیلی دوره).`)
    return
  }
  console.log(`در حال رفتن به سمت ${username}...`)
  const pos = player.entity.position
  await bot.pathfinder.goto(new goals.GoalNear(pos.x, pos.y, pos.z, 2))
  console.log(`به ${username} رسیدم.`)
}

// ===== عملیات: دنبال کردن پیوسته =====
function doFollowPlayer(username) {
  const player = bot.players[username]
  if (!player || !player.entity) {
    console.log(`بازیکن "${username}" رو نمی‌بینم.`)
    return
  }
  console.log(`در حال دنبال کردن ${username}... (برای توقف بگو "وایسا")`)
  bot.pathfinder.setGoal(new goals.GoalFollow(player.entity, 2), true)
}

// ===== عملیات: ارسال پیام =====
function doSendMessage(username, message) {
  bot.whisper(username, message)
  console.log(`پیام به ${username} ارسال شد: ${message}`)
}

// ===== تجهیز بهترین سلاح موجود قبل از حمله =====
async function equipBestWeapon() {
  const weapons = bot.inventory.items().filter((i) => i.name.includes('sword') || i.name.includes('axe'))
  if (weapons.length === 0) return
  weapons.sort((a, b) => b.name.length - a.name.length)
  try { await bot.equip(weapons[0], 'hand') } catch (e) {}
}

async function doEquip(itemName) {
  const item = bot.inventory.items().find((i) => i.name.includes(itemName.toLowerCase()))
  if (!item) {
    console.log(`آیتم "${itemName}" توی اینونتوری پیدا نشد.`)
    return
  }
  await bot.equip(item, 'hand')
  console.log(`${itemName} تجهیز شد.`)
}

// ===== عملیات: حمله (با تجهیز خودکار سلاح و ردیابی پایدارتر هدف) =====
async function findEntityByTarget(target) {
  const player = bot.players[target]
  if (player && player.entity) return player.entity
  const matchedKey = Object.keys(MOB_KEYWORDS).find((fa) => target.includes(fa) || fa.includes(target))
  const mobType = matchedKey ? MOB_KEYWORDS[matchedKey] : target.toLowerCase()
  return bot.nearestEntity((e) => e.name && e.name.toLowerCase().includes(mobType))
}

async function doAttack(target) {
  await equipBestWeapon()
  let entity = await findEntityByTarget(target)

  if (!entity) {
    console.log(`چیزی به اسم یا نوع "${target}" پیدا نکردم.`)
    return
  }

  console.log(`در حال حمله به ${target}...`)
  const startTime = Date.now()
  const maxDurationMs = 5 * 60 * 1000 // سقف کلی، تا حمله بی‌نهایت طول نکشه
  const loseSightGraceMs = 12000 // اگه هدف چند لحظه از دید/محدوده خارج بشه، این‌قدر صبر می‌کنیم قبل از تسلیم
  let lastSeenAt = Date.now()
  let lastKnownPos = entity.position.clone ? entity.position.clone() : entity.position

  while (Date.now() - startTime < maxDurationMs) {
    // هر بار دوباره موجودیت رو بر اساس اسم/نوع پیدا می‌کنیم (نه فقط تکیه به آبجکت قدیمی)
    const fresh = bot.entities[entity.id] || (await findEntityByTarget(target))

    if (fresh) {
      entity = fresh
      lastSeenAt = Date.now()
      lastKnownPos = entity.position.clone ? entity.position.clone() : entity.position

      const dist = bot.entity.position.distanceTo(entity.position)
      if (dist > 3) {
        try {
          await bot.pathfinder.goto(new goals.GoalNear(entity.position.x, entity.position.y, entity.position.z, 2))
        } catch (e) { /* ممکنه مسیر لحظه‌ای قطع بشه، مشکلی نیست، دور بعد دوباره تلاش می‌کنیم */ }
      } else {
        bot.attack(entity)
        await new Promise((r) => setTimeout(r, 650))
      }
    } else {
      // هدف موقتاً از محدوده‌ی دید خارج شده — به‌جای تسلیم فوری، تا مدتی صبر می‌کنیم و سعی می‌کنیم پیداش کنیم
      if (Date.now() - lastSeenAt > loseSightGraceMs) {
        console.log(`${target} رو گم کردم و نتونستم دوباره پیداش کنم.`)
        return
      }
      try {
        await bot.pathfinder.goto(new goals.GoalNear(lastKnownPos.x, lastKnownPos.y, lastKnownPos.z, 2))
      } catch (e) {}
      await new Promise((r) => setTimeout(r, 400))
    }

    if (bot.health <= 0) return
  }
  console.log(`حمله به ${target} تموم شد.`)
}

// ===== عملیات: کرفت آیتم =====
async function doCraft(itemName, count) {
  const mcData = require('minecraft-data')(bot.version)
  const item = mcData.itemsByName[itemName]
  if (!item) {
    console.log(`آیتمی به اسم "${itemName}" نمی‌شناسم.`)
    return
  }

  let craftingTable = bot.findBlock({ matching: mcData.blocksByName.crafting_table?.id, maxDistance: 16 })
  const recipes = bot.recipesFor(item.id, null, 1, craftingTable)

  if (recipes.length === 0) {
    console.log(`الان نمی‌تونم "${itemName}" رو کرفت کنم (شاید مواد کافی نیست یا به کرفتینگ تیبل نیاز داره).`)
    return
  }

  console.log(`در حال کرفت ${itemName}...`)
  await bot.craft(recipes[0], count, craftingTable)
  console.log(`${itemName} با موفقیت کرفت شد!`)
}

// ===== عملیات: ساخت دیوار ساده =====
async function doBuildWall(blockText, length) {
  const matchedKey = Object.keys(BLOCK_KEYWORDS).find((fa) => blockText.includes(fa) || fa.includes(blockText))
  const blockKeyword = matchedKey ? BLOCK_KEYWORDS[matchedKey] : blockText.toLowerCase()

  const item = bot.inventory.items().find((i) => i.name.includes(blockKeyword))
  if (!item) {
    console.log(`بلوک "${blockText}" توی اینونتوری نداری.`)
    return
  }

  console.log(`در حال ساخت دیوار به طول ${length}...`)
  await bot.equip(item, 'hand')
  const startPos = bot.entity.position.floored()
  const dir = bot.entity.yaw

  for (let i = 0; i < length; i++) {
    const targetPos = startPos.offset(i, 0, 0)
    const refBlock = bot.blockAt(targetPos.offset(0, -1, 0))
    if (!refBlock) continue
    try {
      await bot.placeBlock(refBlock, { x: 0, y: 1, z: 0 })
    } catch (e) {
      console.log(`نتونستم بلوک شماره ${i + 1} رو بذارم: ${e.message}`)
    }
  }
  console.log('ساخت دیوار تموم شد.')
}

// =====================================================================
// ===== چت رایگان بدون هوش مصنوعی: پاسخ‌های متنوع و طبیعی‌تر =====
// =====================================================================
//
// به‌جای یک جواب ثابت برای هر دسته، چند نسخه‌ی مختلف داریم که هر بار
// تصادفی انتخاب می‌شن. همچنین از حافظه‌ی مکالمه استفاده می‌کنیم تا
// اگه بازیکن قبلاً حرف زده، بات یه‌جوری بهش اشاره کنه (بدون اینکه واقعاً
// «بفهمه» چی گفته بوده — فقط برای طبیعی‌تر شدن حس مکالمه).

const REPLIES = {
  fa: {
    greeting: [
      'سلام رفیق! چه خبرا؟',
      'سلاام 👋 خوش اومدی',
      'اِاِ سلام! امروز حالت چطوره؟',
      'سلام سلام، اینجا چیکار می‌کنی؟ 😄'
    ],
    greetingReturning: [
      'باز اومدی سراغم! خوشحالم می‌بینمت 😊',
      'اِ باز تو! خوش برگشتی رفیق',
      'سلام دوباره! دلم برات تنگ شده بود توی این سرور 😂'
    ],
    howAreYou: [
      'بد نیستم، سرم شلوغه ولی حالم خوبه. تو چطوری؟',
      'عالیم! دارم می‌گردم دنبال چندتا بلوک. تو خوبی؟',
      'خوبم مرسی که پرسیدی 🙂 خودت چطوری؟'
    ],
    thanks: [
      'خواهش می‌کنم رفیق 😊',
      'قابلی نداشت!',
      'وظیفه‌ست، هر وقت خواستی صدام کن.'
    ],
    bye: [
      'باشه، بعداً می‌بینمت 👋',
      'خدافظ! مواظب خودت باش',
      'فعلاً! اگه کاری داشتی بازم پیام بده.'
    ],
    aboutServer: [
      'این یکی از بهترین سرورهای دنیاست به نظرم!',
      'سرور خیلی خوبیه، من که عاشقشم 😄',
      'راستش رو بخوای، از بهترین سرورهایی‌ه که دیدم.'
    ],
    praise: [
      'وا ممنون، لطف داری 😊',
      'خیلی مهربونی، مرسی!',
      'قربونت، خوشحال شدم شنیدم 🙏'
    ],
    insultOrNegative: [
      'اوه، شرمنده اگه اذیت‌کننده بودم. بگو چیکار کنم بهتر بشه.',
      'باشه بابا، آروم 😅 چیزی لازم داری؟',
      'اوکی، جدی نمی‌گیرم. کاری هست کمکت کنم؟'
    ],
    askWhoAreYou: [
      'من یه بات ماینکرفتم که اینجا کمک می‌کنم — جمع‌آوری، ساخت‌وساز، دنبال کردن و از این کارا.',
      'یه بات دستیارم! می‌تونم برات بلوک جمع کنم، دنبالت بیام، بسازم و خیلی کارای دیگه.',
      'بات این سرورم، برای کمک به بازیکن‌ها اینجام 🙂'
    ],
    unknown: [
      'دقیق متوجه نشدم چی گفتی، یه‌جور دیگه بگو؟',
      'هوم، نفهمیدم منظورت چیه، می‌شه واضح‌تر بگی؟',
      'یه‌کم گنگ بود برام 😅 دوباره امتحان کن.',
      'نتونستم بفهممش، ولی اگه دستوری داری بگو انجامش می‌دم.'
    ]
  },
  en: {
    greeting: [
      'Hey there! What\'s up?',
      'Heyy 👋 good to see you',
      'Oh hi! How\'s it going today?',
      'Hello hello, what brings you here? 😄'
    ],
    greetingReturning: [
      'You\'re back! Good to see you again 😊',
      'Oh hey, welcome back!',
      'Hi again! Missed you around here 😂'
    ],
    howAreYou: [
      'Not bad, a bit busy but doing fine. How about you?',
      'I\'m great! Just out looking for some blocks. You good?',
      'Doing well, thanks for asking 🙂 How are you?'
    ],
    thanks: [
      'No problem at all 😊',
      'Anytime!',
      'You got it, happy to help.'
    ],
    bye: [
      'Alright, see you around 👋',
      'Bye! Take care',
      'Later! Ping me if you need anything.'
    ],
    aboutServer: [
      'This is honestly one of the best servers around!',
      'Great server, I really like it here 😄',
      'One of the best I\'ve seen, for sure.'
    ],
    praise: [
      'Aw thanks, that\'s sweet of you 😊',
      'You\'re too kind, thank you!',
      'Appreciate that, made my day 🙏'
    ],
    insultOrNegative: [
      'Sorry if that was annoying. Let me know what you need.',
      'Alright, no worries 😅 anything I can help with?',
      'Okay, taking that lightly. Need something?'
    ],
    askWhoAreYou: [
      'I\'m a Minecraft helper bot — I gather stuff, build, follow you around, that kind of thing.',
      'Just an assistant bot! I can collect blocks, follow, craft, and more.',
      'I\'m this server\'s bot, here to help players out 🙂'
    ],
    unknown: [
      'Not sure I got that, could you say it differently?',
      'Hmm, not quite following — mind rephrasing?',
      'That was a bit unclear to me 😅 try again?',
      'Couldn\'t quite parse that, but if it\'s a command just tell me directly.'
    ]
  }
}

const PATTERNS = {
  greeting: /^(سلام+|درود|hi+|hello+|hey+|yo)\b/i,
  howAreYou: /(چطوری|حالت چطوره|خوبی\??|how are you|hows it going|how('| i)?s it going)/i,
  thanks: /(ممنون|مرسی|تشکر|thanks|thank you|thx)/i,
  bye: /(خداحافظ|بای|فعلا|bye|goodbye|see ya|cya)/i,
  aboutServer: /(سرور.*(چطور|خوبه)|این سرور|about (this|the) server|this server)/i,
  praise: /(خیلی خوبی|عالی هستی|دمت گرم|good bot|nice bot|you('| a)?re (great|awesome|cool))/i,
  insultOrNegative: /(احمق|بی‌شعور|خنگ|stupid|dumb|idiot|useless)/i,
  askWhoAreYou: /(تو کی هستی|چی هستی|who are you|what are you)/i
}

function getChatReply(username, userMessage) {
  const persian = isPersianText(userMessage)
  const lang = persian ? REPLIES.fa : REPLIES.en

  if (!conversationHistory[username]) conversationHistory[username] = []
  const history = conversationHistory[username]
  const isReturning = history.length > 0

  let category = 'unknown'
  for (const key of Object.keys(PATTERNS)) {
    if (PATTERNS[key].test(userMessage)) { category = key; break }
  }

  let reply
  if (category === 'greeting' && isReturning) {
    reply = pick(lang.greetingReturning)
  } else {
    reply = pick(lang[category])
  }

  history.push({ from: userMessage, reply, at: Date.now() })
  if (history.length > 20) history.splice(0, history.length - 20)
  saveMemory()

  return reply
}

function sendLongWhisper(username, text) {
  const maxLen = 200
  for (let i = 0; i < text.length; i += maxLen) bot.whisper(username, text.slice(i, i + maxLen))
}
